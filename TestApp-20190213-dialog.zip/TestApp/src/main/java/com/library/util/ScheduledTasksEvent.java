package com.library.util;

public class ScheduledTasksEvent {

	private String eventInfo;
	private long time = System.currentTimeMillis();
	
	public ScheduledTasksEvent(String s) {
		this.eventInfo = s;
		System.out.println(this.toString());
	}

	public String getEventInfo() {
		return eventInfo;
	}

	public void setEventInfo(String eventInfo) {
		this.eventInfo = eventInfo;
	}

	public long getTime() {
		return time;
	}

	public void setTime(long time) {
		this.time = time;
	}

	@Override
	public String toString() {
		return "ScheduledTasksEvent [eventInfo=" + eventInfo + ", time=" + time + "]";
	}
	
}

package com.library.tester;

import javax.ejb.Schedule;
import javax.ejb.Singleton;
import javax.ejb.Timer;
import javax.enterprise.event.Event;
import javax.inject.Inject;

import com.library.util.ScheduledTasksEvent;

@Singleton
public class ScheduledTasks {
	
	@Inject
	Event<ScheduledTasksEvent> event;

	@Schedule(hour = "*", minute = "*", second = "*/5", info = "Every 5 second timer")
	public void automaticallyScheduled(Timer timer) {
		event.fire(new ScheduledTasksEvent(timer.getInfo().toString()));
	}
	
}
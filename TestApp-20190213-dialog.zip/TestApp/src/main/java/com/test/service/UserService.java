package com.test.service;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Named;

import com.test.model.User;

@Named
@ApplicationScoped
public class UserService implements Serializable {

	private static final long serialVersionUID = 1L;
	
	public List<User> findAllUsers() {
		List<User> users = new ArrayList<User>();
		users.add(new User(1L, "houwaey0", "houwaey0@email.com", "ACTIVE"));
		users.add(new User(1L, "houwaey1", "houwaey1@email.com", "INACTIVE"));
		users.add(new User(1L, "houwaey2", "houwaey2@email.com", "LOCKED"));
		return users;
	}

}

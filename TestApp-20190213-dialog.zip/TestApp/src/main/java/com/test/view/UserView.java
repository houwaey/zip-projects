package com.test.view;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.inject.Named;

import org.omnifaces.cdi.ViewScoped;

import com.test.model.User;
import com.test.service.UserService;

@Named
@ViewScoped
public class UserView implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private UserService userService;

	private String remarks;
	private String password;
	private List<User> users;
	private User selectedUser;
	
	@PostConstruct
	public void init() {
		users = userService.findAllUsers();
	}
	
	public void deactivate() {
		System.out.println(selectedUser);
		System.out.println("remarks: " + remarks);
		System.out.println("password: " + password);
	}

	public UserService getUserService() {
		return userService;
	}

	public void setUserService(UserService userService) {
		this.userService = userService;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public List<User> getUsers() {
		return users;
	}

	public void setUsers(List<User> users) {
		this.users = users;
	}

	public User getSelectedUser() {
		return selectedUser;
	}

	public void setSelectedUser(User selectedUser) {
		this.selectedUser = selectedUser;
	}

}

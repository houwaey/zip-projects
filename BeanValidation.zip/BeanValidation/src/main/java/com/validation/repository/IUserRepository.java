package com.validation.repository;

import java.util.List;

import com.validation.model.User;

public interface IUserRepository {

	void registerNewUserAccount(User user);
	
	List<User> findAll();
	
	boolean isEmailExist(User user);
	
}

package com.validation.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.validation.model.User;

@Repository
public class UserRepository implements IUserRepository {

	private List<User> users = new ArrayList<User>();
	
	@Override
	public void registerNewUserAccount(User user) {
		users.add(user);
	}

	@Override
	public boolean isEmailExist(User user) {
		return users.contains(user) ? true : false;
	}

	@Override
	public List<User> findAll() {
		return users;
	}

}

package com.validation.app;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.validation.common.ResponseObject;
import com.validation.model.User;
import com.validation.service.IUserService;

@RestController
@RequestMapping("/user")
public class UserController {
	
	@Autowired
	private IUserService service;
	
	@PostMapping("/save")
	public ResponseObject<Void> saveUser(@Valid User user) {
		service.registerNewUserAccount(user);
		return new ResponseObject<Void>(HttpStatus.OK);
	}

	@GetMapping("/find-all")
	public ResponseObject<List<User>> findAll() {
		List<User> users = service.findAllUsers();
		if (users.size() <= 0) {
			return new ResponseObject<List<User>>(HttpStatus.NO_CONTENT);
		}
		return new ResponseObject<List<User>>(users, HttpStatus.FOUND);
	}
	
}
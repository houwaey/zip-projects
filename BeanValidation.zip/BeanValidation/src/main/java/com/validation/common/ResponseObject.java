package com.validation.common;

import org.springframework.http.HttpStatus;

public class ResponseObject<T> {

	private int code;
	private String message;
	private T data;
	
	public ResponseObject(HttpStatus httpStatus) {
		this.code = httpStatus.value();
		this.message = httpStatus.getReasonPhrase();
	}
	
	public ResponseObject(HttpStatus httpStatus, String customMessage) {
		this.code = httpStatus.value();
		this.message = customMessage;
	}
	
	public ResponseObject(T data, HttpStatus httpStatus) {
		this.code = httpStatus.value();
		this.message = httpStatus.getReasonPhrase();
		this.data = data;
	}
	
	public ResponseObject(T data, HttpStatus httpStatus, String customMessage) {
		this.code = httpStatus.value();
		this.message = customMessage;
		this.data = data;
	}
	
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public T getData() {
		return data;
	}
	public void setData(T data) {
		this.data = data;
	}
	
}

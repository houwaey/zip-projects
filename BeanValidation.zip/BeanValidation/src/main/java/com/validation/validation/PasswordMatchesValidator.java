package com.validation.validation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.validation.model.User;

public class PasswordMatchesValidator implements ConstraintValidator<PasswordMatches, Object> {

	@Override
	public void initialize(PasswordMatches constraintAnnotation) {

	}

	@Override
	public boolean isValid(Object object, ConstraintValidatorContext context) {
		final User user = (User) object;
		return user.getPassword().equals(user.getMatchingPassword());
	}

}

package com.validation.service;

import java.util.List;

import com.validation.exception.UserAlreadyExistException;
import com.validation.model.User;

public interface IUserService {

	void registerNewUserAccount(User user) throws UserAlreadyExistException;
	
	List<User> findAllUsers();
	
}

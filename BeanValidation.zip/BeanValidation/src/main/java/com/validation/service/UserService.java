package com.validation.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.validation.exception.UserAlreadyExistException;
import com.validation.model.User;
import com.validation.repository.IUserRepository;

@Service
@Transactional
public class UserService implements IUserService {

	@Autowired
	private IUserRepository repository;

	@Override
	public void registerNewUserAccount(User user) throws UserAlreadyExistException {
		if (repository.isEmailExist(user)) {
			throw new UserAlreadyExistException("There is an account with that email address: " + user.getEmail());
		}
		repository.registerNewUserAccount(user);
	}

	@Override
	public List<User> findAllUsers() {
		return repository.findAll();
	}

}

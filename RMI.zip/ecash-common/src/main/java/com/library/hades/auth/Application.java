package com.library.hades.auth;

public abstract class Application {

	protected String address;
	protected Integer appid;
	protected String prefix;
	protected boolean shouldValidateIp;
	
	public boolean allowed(String[] ips){
		if(this.shouldValidateIp){
			for(String ip:ips){
				if(!ip.trim().equals(this.address)) return false;
			}
		}
		return true;
	}

	public Integer getAppid() {
		return appid;
	}

	public void setAppid(Integer appid) {
		this.appid = appid;
	}

	public String getPrefix() {
		return prefix;
	}

	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public boolean isShouldValidateIp() {
		return shouldValidateIp;
	}

	public void setShouldValidateIp(boolean shouldValidateIp) {
		this.shouldValidateIp = shouldValidateIp;
	}

}

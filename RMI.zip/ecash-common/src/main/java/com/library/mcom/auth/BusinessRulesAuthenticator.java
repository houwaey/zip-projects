package com.library.mcom.auth;

import java.util.HashMap;

import com.library.mcom.arch.Transaction;
import com.library.mcom.arch.auth.AuthType;
import com.library.mcom.arch.auth.Authenticator;

@SuppressWarnings("serial")
public class BusinessRulesAuthenticator extends Authenticator {

	private HashMap<String, Object> data;

	public BusinessRulesAuthenticator(Transaction t, HashMap<String, Object> data) {
		super(t);
		this.data = data;
	}

	@Override
	public boolean valid() {
		return true;
	}

	@Override
	public AuthType getType() {
		return AuthType.BUSINESS;
	}

}

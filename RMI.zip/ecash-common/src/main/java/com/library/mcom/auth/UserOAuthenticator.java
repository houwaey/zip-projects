package com.library.mcom.auth;

import com.library.mcom.arch.Transaction;
import com.library.mcom.arch.auth.AuthType;
import com.library.mcom.arch.auth.Authenticator;

@SuppressWarnings("serial")
public class UserOAuthenticator extends Authenticator {

	public UserOAuthenticator(Transaction t,String value) {
		super(t);
	}

	@Override
	public AuthType getType() {
		return null;
	}

	@Override
	public boolean valid() {
		return false;
	}

}

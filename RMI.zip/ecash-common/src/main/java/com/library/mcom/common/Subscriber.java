package com.library.mcom.common;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.library.common.Log;
import com.library.common.StringUtil;
import com.library.jdbc.database.DbWrapper;
import com.library.jdbc.database.DbWrapperFactory;
import com.library.mcom.util.Query;
import com.library.regex.NamedMatcher;
import com.library.regex.NamedPattern;

public class Subscriber {

	private static final DbWrapper db = DbWrapperFactory.getDb();
	private static final Pattern aliasPattern = Pattern.compile("^\\d{1,5}$|.*[^\\d\\+]+.*");
	private static final NamedPattern localPattern = getLocalPattern();
	private static final NamedPattern roamingPattern = getRoamingPattern();
	private static final NamedPattern localnetPattern = getLocalNetPattern();
	private static final NamedPattern roamingnetPattern = getRoamingNetPattern();

	protected boolean local = false;
	protected boolean roaming = false;
	protected boolean othernet = false;
	protected boolean alias = false;
	protected String msisdn;
	protected String subscriberId;
	protected String countryCode;

	public boolean isLocal() {
		return local;
	}

	public boolean isRoaming() {
		return roaming;
	}

	public boolean isOthernet() {
		return othernet;
	}

	public boolean isAlias() {
		return alias;
	}

	public String getMsisdn() {
		return msisdn;
	}

	public void setMsisdn(String msisdn) {
		init(msisdn);
	}

	public Subscriber(String msisdn) {
		local = false;
		roaming = false;
		othernet = false;
		alias = false;
		init(msisdn);
	}
	
	public void init(String msisdn) {
		NamedMatcher match = localPattern.matcher(msisdn);
		if (match.matches()) {
			local = true;
			if (match.group("countrycode") == null) {
				countryCode = SystemInfo.getProperty(SystemInfo.PROP_COUNTRY_CODE, "63");
			} else {
				countryCode = match.group("countrycode");
			}
			subscriberId = match.group("msisdn");
			this.msisdn = countryCode + subscriberId;
			return;
		}
		
		match = roamingPattern.matcher(msisdn);
		if (match.matches()) {
			roaming = true;
			countryCode = match.group("countrycode");
			subscriberId = match.group("msisdn");
			this.msisdn = countryCode + subscriberId;
			return;
		}
		
		match = localnetPattern.matcher(msisdn);
		if (match.matches()) {
			local = true;
			othernet = true;
			if (match.group("countrycode") == null) {
				countryCode = SystemInfo.getProperty(SystemInfo.PROP_COUNTRY_CODE, "63");
			} else {
				countryCode = match.group("countrycode");
			}
			subscriberId = match.group("msisdn");
			this.msisdn = countryCode + subscriberId;
			return;
		}
		
		match = roamingnetPattern.matcher(msisdn);
		if (match.matches()) {
			roaming = true;
			othernet = true;
			countryCode = match.group("countrycode");
			subscriberId = match.group("msisdn");
			this.msisdn = countryCode + subscriberId;
			return;
		}
		
		Matcher matcher = aliasPattern.matcher(msisdn);
		if (matcher.matches()) {
			alias = true;
			return;
		}
	}
	
	private static final NamedPattern getLocalPattern() {
		String[] patterns = db.QueryArray(Query.LOCALPATTERN, "^$");
		if (patterns != null && patterns.length > 0) {
			return NamedPattern.compile(StringUtil.join(patterns, "|"));
		}
		return NamedPattern.compile("^$");
	}
	
	private static final NamedPattern getRoamingPattern() {
		String[] patterns = db.QueryArray(Query.ROAMINGNETPATTERN, "^$");
		if (patterns != null && patterns.length > 0) {
			return NamedPattern.compile(StringUtil.join(patterns, "|"));
		}
		return NamedPattern.compile("^$");
	}
	
	private static final NamedPattern getLocalNetPattern() {
		String[] patterns = db.QueryArray(Query.LOCALNETPATTERN, "^$");
		if (patterns != null && patterns.length > 0) {
			return NamedPattern.compile(StringUtil.join(patterns, "|"));
		}
		return NamedPattern.compile("^$");
	}
	
	private static final NamedPattern getRoamingNetPattern() {
		String[] patterns = db.QueryArray(Query.ROAMINGNETPATTERN, "^$");
		if (patterns != null && patterns.length > 0) {
			return NamedPattern.compile(StringUtil.join(patterns, "|"));
		}
		return NamedPattern.compile("^$");
	}

}

package com.library.mcom.common;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.json.simple.JSONObject;

import com.library.common.Base64;
import com.library.common.Hash;
import com.library.common.Log;
import com.library.common.LongUtil;
import com.library.hades.auth.Application;
import com.library.jdbc.database.DataRow;
import com.library.jdbc.database.DataRowCollection;
import com.library.jdbc.database.DbWrapper;
import com.library.jdbc.database.DbWrapperFactory;
import com.library.mcom.arch.Adjustment;
import com.library.mcom.arch.Adjustments;
import com.library.mcom.arch.Entry;
import com.library.mcom.arch.EntryType;
import com.library.mcom.arch.ExternalTask;
import com.library.mcom.arch.ExternalTasks;
import com.library.mcom.arch.Particulars;
import com.library.mcom.arch.Response;
import com.library.mcom.arch.Rewards;
import com.library.mcom.arch.SubsidiaryDetail;
import com.library.mcom.arch.Verification;
import com.library.mcom.arch.aml.BreachListener;
import com.library.mcom.policies.BusinessPolicies;
import com.library.mcom.util.Query;

public class Transaction extends com.library.mcom.arch.Transaction {

	private static final long serialVersionUID = 1L;

	static SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd hh:mm");
	private static DbWrapper db = DbWrapperFactory.getDb();
	private static SimpleDateFormat dfLifetime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	private Application app = null;
	private int remainingLock = 0;
	private StringBuilder entriesHash = new StringBuilder("");
	private Date startDate;
	private Date endDate;

	Integer glid = 0;

	public Application getApp() {
		return app;
	}

	public void setApp(Application app) {
		this.app = app;
		this.appid = this.app.getAppid();
		this.prefix = this.app.getPrefix();
	}

	public Transaction(Application app) {
		super();
		this.setApp(app);
	}

	public static Transaction from(Transaction t) {
		Transaction ret = new Transaction();
		ret.setAmount(t.getAmount());
		ret.setAppid(t.getAppid());
		ret.setPrefix(t.getPrefix());
		ret.setApp(t.getApp());
		ret.setAuth(t.getAuth());
		ret.setCards(new ArrayList<>(t.getCards()));
		ret.setContext(t.getContext());
		ret.setData(new HashMap<String, Object>(t.getData()));
		ret.setDestination(t.getDestination());
		ret.setMainWallet(t.pocket);
		ret.setKey(t.getKey());
		ret.setRequestAddress(t.getRequestAddress());
		ret.setRequestProxies(t.getRequestProxies());
		ret.setRequestId(t.getRequestId());
		ret.setResponseId(t.getResponseId());
		ret.setRules(t.rules);
		ret.setSource(t.getSource());
		ret.setStatus(t.getStatus());
		ret.setType(t.getType());
		ret.setVerification(t.getVerification());
		for (String key : t.headers.keySet()) {
			ret.headers.put(key, t.headers.get(key));
		}
		return ret;
	}

	@Override
	public boolean allowed() {
		if (!this.getApp().allowed(this.requestProxies)) {
			return false;
		}

		this.loadAdjustments();
		if (context instanceof BreachListener) {
			this.setRules(new BusinessPolicies(this, (BreachListener) context));
		}
		
		String destAcct = this.destination != null ? this.getDestination().getMsisdn().toString() : "";
		String destFqn = this.destination != null ? this.getDestination().getAlias() : "";
		String destNet = this.destination != null ? this.getDestination().getNetwork().toString() : "";
		String destType = this.destination != null ? this.getDestination().getType() : "";

		return db.QueryScalar(
				"SELECT RULE FROM\n" + " (SELECT * FROM SETTINGS_ACCESS_CONTROL\n"
						+ " WHERE ((SOURCE IN ('*',?,?) OR INSTR(?,SOURCE)>0)  AND SOURCETYPE IN ('*',?))\n"
						+ " AND ((DEST IN ('*',?,?) OR INSTR(?,DEST)>0)  AND DESTTYPE IN ('*',?))\n"
						+ " AND KEY IN ('*',?)\n" + " ORDER BY SOURCE DESC,DEST DESC,RULE DESC) WHERE ROWNUM=1",
				"DENY", this.getSource().getMsisdn(), this.getSource().getAlias(),
				this.getSource().getNetwork().toString(), this.getSource().getType(), destAcct, destFqn, destNet,
				destType, this.getKey()).equals("ALLOW");
	}

	@Override
	public void start() {
		try {
			this.startDate = new Date();
			this.responseId = SystemInfo.getTransId(this.prefix);
			this.requestId = this.requestId == null ? this.responseId : this.requestId;
		} catch (Exception e) {
			Log.server(e);
		}
		db.QueryUpdate(
				"INSERT INTO TRANSACTION_RECEIVED(REQUESTID,REFERENCEID,APPID,KEY,SENDER,MESSAGE,HASH) VALUES(?,?,?,?,?,?,?)",
				this.requestId, this.responseId, this.appid, this.key, this.source.toString(),
				"TODO: not sure what to put", this.hash());
	}

	@Override
	public String previous() {
		return db
				.QueryScalar(
						"SELECT P.REFERENCEID FROM TRANSACTION_RESPONSE P INNER JOIN TRANSACTION_RECEIVED H ON H.REFERENCEID=P.REFERENCEID WHERE APPID=? AND H.REQUESTID=?",
						"", this.appid, this.requestId);
	}

	@Override
	public boolean locked(int seconds) {
		this.remainingLock = db
				.QueryScalar(
						"SELECT ( (TIMESTAMP+?/86400)-SYSDATE)*86400 L FROM (SELECT TIMESTAMP FROM TRANSACTION_RECEIVED WHERE HASH=? ORDER BY TIMESTAMP DESC) WHERE ROWNUM=1",
						0, seconds, this.hash());
		return remainingLock > 0;
	}

	@Override
	public boolean execute() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean reward() {
		this.rewards = new Rewards(this);
		if (this.rewards != null && this.rewards.size() > 0) {
			StringBuilder dml = new StringBuilder();
			ArrayList<Object> params = new ArrayList<Object>();
			addheader(dml, params, this.responseId, this.key, this.source, this.requestId, "", this.pocket);
			for (Adjustment a : this.rewards) {
				if (a.getType() == EntryType.CREDIT) {
					creditAccount(dml, params, a.getAccount(), this.key, a.getAmount(), glid, a.getRemarks(), a
							.getPocket().getId(), a.getAccountType());
					dml.append("        vDESTBEFORE := vTEMPBEFORE;\n        vDESTAFTER := vTEMPAFTER;\n");
					debitAccount(dml, params, a.getDest(), this.key, a.getAmount(), glid, a.getRemarks(), a.getPocket()
							.getId(), false, a.getAccountType());
					dml.append("        vORIGBEFORE := vTEMPBEFORE;\n        vORIGAFTER := vTEMPAFTER;\n");
					glid++;
				}
			}
			addtailadj(dml);
			int status = db.QueryUpdate(dml.toString(), params.toArray());
			return status > -1;

		}
		return true;
	}

	@Override
	public boolean adjust(Adjustments entries) {
		if (entries != null && entries.size() > 0) {
			StringBuilder dml = new StringBuilder();
			ArrayList<Object> params = new ArrayList<Object>();
			addadjheader(dml, params, this.responseId, this.key, this.source, this.requestId, "", this.pocket);
			for (Adjustment a : entries) {
				if (a.getType() == EntryType.CREDIT) {
					creditAccount(dml, params, a.getAccount(), this.key, a.getAmount(), glid, a.getRemarks(), a
							.getPocket().getId(), a.getAccountType());
					dml.append("        vDESTBEFORE := vTEMPBEFORE;\n        vDESTAFTER := vTEMPAFTER;\n");
					debitAccount(dml, params, a.getDest(), this.key, a.getAmount(), glid, a.getRemarks(), a.getPocket()
							.getId(), false, a.getAccountType());
					dml.append("        vORIGBEFORE := vTEMPBEFORE;\n        vORIGAFTER := vTEMPAFTER;\n");
					glid++;
				} else {
					debitAccount(dml, params, a.getAccount(), this.key, a.getAmount(), glid, a.getRemarks(), a
							.getPocket().getId(), false, a.getAccountType());
					dml.append("        vORIGBEFORE := vTEMPBEFORE;\n        vORIGAFTER := vTEMPAFTER;\n");
					creditAccount(dml, params, a.getDest(), this.key, a.getAmount(), glid, a.getRemarks(), a
							.getPocket().getId(), a.getAccountType());
					dml.append("        vDESTBEFORE := vTEMPBEFORE;\n        vDESTAFTER := vTEMPAFTER;\n");

					glid++;
				}
			}
			addtailadj(dml);
			int status = db.QueryUpdate(dml.toString(), params.toArray());
			return status > -1;

		}
		return true;
	}

	@Override
	public boolean rollback() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	protected void loadAdjustments() {
		// TODO Auto-generated method stub

	}

	@Override
	protected boolean consume(Verification v) {
		if (!v.verified()) {
			return false;
		}
		StringBuilder dml = new StringBuilder();
		ArrayList<Object> params = new ArrayList<Object>();
		addheader(dml, params, this.responseId, this.key, this.source, this.requestId, "", this.pocket);
		for (Entry a : this.entries) {
			a.setRemarks(v.getTransid());
			int w = this.getVerification() != null ? -a.getPocket().getId() : a.getPocket().getId();
			creditAccount(dml, params, this.source, this.key, a.getAmount(), glid, a.getRemarks(), a.getPocket()
					.getId(), a.getAccountType());
			dml.append("        vORIGBEFORE := vTEMPBEFORE;\n        vORIGAFTER := vTEMPAFTER;\n");
			debitAccount(dml, params, a.getDest(), this.key, a.getAmount(), glid, a.getRemarks(), w, false,
					a.getAccountType());
			dml.append("        vDESTBEFORE := vTEMPBEFORE;\n        vDESTAFTER := vTEMPAFTER;\n");
			glid++;
		}
		dml.append("DELETE FROM TBLVERIFICATIONS WHERE REFERENCEID='" + v.getTransid() + "';\n");
		addtail(dml, params, this.source, this.destination, this.amount);
		int status = db.QueryUpdate(dml.toString(), params.toArray());
		return status > -1;
	}

	@Override
	public Particulars particulars() {
		Particulars p = new Particulars();
		DataRowCollection rows = db
				.QueryDataRows(
						"SELECT CREDIT,DEBIT,BALANCEBEFORE,BALANCEAFTER,REMARKS FROM TRANSACTION_PARTICULARS WHERE REFERENCEID = ? AND MOBILENUMBER=? ORDER BY GLID ASC",
						this.responseId, this.source.getMsisdn());
		if (!rows.isEmpty()) {
			rows.forEach(row -> {
				SubsidiaryDetail detail = new SubsidiaryDetail();
				// detail.setAccount(row.getString("ACCOUNT"));
				detail.setDescription(row.getString("REMARKS").isEmpty() ? this.type : row.getString("REMARKS"));
				detail.setCredit(LongUtil.toString(row.getLong("CREDIT")));
				detail.setDebit(LongUtil.toString(row.getLong("DEBIT")));
				detail.setBalanceBefore(LongUtil.toString(row.getLong("BALANCEBEFORE")));
				detail.setBalanceAfter(LongUtil.toString(row.getLong("BALANCEAFTER")));
				p.add(detail);
			});
		}
		return p;
	}

	@Override
	public void end(Response r) {
		this.status = r;
		this.status.isSuccessful(r.getCode() == 0);
		this.status.addData("date", df.format(new Date()));

		r.substitute("<date>", df.format(new Date()));

		this.responseData.keySet().forEach(key -> {
			r.put(key, this.responseData.get(key));
		});

		if (r.getCode() == 0 && this.getDestination().getId() != 0) {
			this.reward();
		}

		this.endDate = new Date();
		db.QueryUpdate(
				"INSERT INTO TRANSACTION_RESPONSE(REQUESTID,REFERENCEID,STATUS,MESSAGE,OBJECT) VALUES(?,?,?,?,?)",
				this.requestId, this.responseId, r.getCode(), r.getMessage(), JSONObject.toJSONString(r));
		if (this.status.success() || this.status.timeout()) {
			this.tasks = new ExternalTasks(this);
			this.onPostExecution();
		}
	}

	@Override
	public Entry lastEntry() {
		Entry e = null;
		DataRow row = db.QueryDataRow("SELECT * FROM TRANSACTION_PARTICULARS WHERE REFERENCEID = ? ORDER BY GLID DESC",
				this.responseId);
		if (row.size() > 0) {
			e = new Entry();
			e.setId(row.getInteger("GLID"));
			this.glid = e.getId();
			e.setPocket(new Pocket(row.getInteger("WALLETID"), "", 0l));
			if (row.getLong("DEBIT") == 0) {
				e.setType(EntryType.CREDIT);
				e.setAmount(row.getLong("CREDIT"));
			}

		}
		return e;
	}

	@Override
	public void onPostExecution() {
		try {
			if (this.tasks != null)
				this.tasks.forEach(e -> e.execute());
		} catch (Exception e) {
			Log.server(e);
		}
	}

	@Override
	public void add(Entry e) {
		entriesHash.append(e.getAmount() + e.getRemarks() + e.getType().toString());
		super.add(e);
	}

	public String hash() {
		try {
			String data = this.appid + this.source.getMsisdn().toString()
					+ (this.data != null ? JSONObject.toJSONString(this.data) : "") + this.key;
			return Hash.hashSHA256(data);
		} catch (UnsupportedEncodingException e) {
			return "";
		}
	}

	protected static void addtail(StringBuilder sql, ArrayList<Object> parameters,
			com.library.mcom.arch.McomSubscriber originator, com.library.mcom.arch.McomSubscriber destination,
			long amount) {
		sql.append(Query.sqlTail);
		parameters.add(destination.getMsisdn());
		parameters.add(amount);
		parameters.add(originator.getAlias());
		parameters.add(destination.getAlias());
	}

	private static void addtailadj(StringBuilder sql) {
		sql.append(Query.sqlTailadjust);
	}

	protected static void creditAccount(StringBuilder sql, ArrayList<Object> parameters,
			com.library.mcom.arch.McomSubscriber account, String key, long amount, int glid, String remarks,
			int walletid, String accounttype) {
		sql.append(Query.sqlCredit);
		parameters.add(amount);
		parameters.add(account.getMsisdn());
		parameters.add(walletid);
		parameters.add(amount);
		parameters.add(key);
		parameters.add(account.getMsisdn());
		parameters.add(amount);
		parameters.add(remarks);
		parameters.add(account.getAlias());
		parameters.add(glid);
		parameters.add(walletid);
		parameters.add(accounttype);
	}

	protected static void debitAccount(StringBuilder str, ArrayList<Object> parameters,
			com.library.mcom.arch.McomSubscriber account, String key, long amount, int glid, String remarks,
			int walletid, boolean allownegative, String accounttype) {
		str.append(Query.sqlDebit);
		parameters.add(amount);
		parameters.add(account.getMsisdn());
		parameters.add(allownegative ? Long.MIN_VALUE : amount);
		parameters.add(walletid);
		parameters.add(amount);
		parameters.add(key);
		parameters.add(account.getMsisdn());
		parameters.add(amount);
		parameters.add(remarks);
		parameters.add(account.getAlias());
		parameters.add(glid);
		parameters.add(walletid);
		parameters.add(accounttype);
	}

	private static void addadjheader(StringBuilder sql, ArrayList<Object> parameters, String refid, String key,
			com.library.mcom.arch.McomSubscriber originator, String externaldata1, String externaldata2, int walletid) {
		sql.append(Query.sqlheaderwalletadj);
		// variables sysdate, refid, key, externaldata1, externaldata2, cipher
		parameters.add(refid);
		parameters.add(key);
		parameters.add(originator.getMsisdn());
		parameters.add(externaldata1);
		parameters.add(externaldata2);
		parameters.add(db.getCrypt());
		parameters.add(walletid);
	}

	protected static void addheader(StringBuilder sql, ArrayList<Object> parameters, String refid, String key,
			com.library.mcom.arch.McomSubscriber source, String externaldata1, String externaldata2, int walletid) {
		sql.append(Query.sqlheaderwallet);
		// variables sysdate, refid, key, externaldata1, externaldata2, cipher
		parameters.add(refid);
		parameters.add(key);
		parameters.add(source.getMsisdn());
		parameters.add(externaldata1);
		parameters.add(externaldata2);
		parameters.add(db.getCrypt());
		parameters.add(walletid);
	}

	private static void addrollbackheader(StringBuilder sql, ArrayList<Object> parameters, String refid, String key,
			com.library.mcom.arch.McomSubscriber originator, String externaldata1, String externaldata2, int walletid) {
		sql.append(Query.sqlheaderrollback);
		// variables sysdate, refid, key, externaldata1, externaldata2, cipher
		parameters.add(refid);
		parameters.add(key);
		parameters.add(originator.getMsisdn());
		parameters.add(externaldata1);
		parameters.add(externaldata2);
		parameters.add(db.getCrypt());
		parameters.add(walletid);
	}

	public HashMap<String, Object> serialize() {
		HashMap<String, Object> trans = new LinkedHashMap<String, Object>();

		trans.put("request_id", this.requestId);
		trans.put("response_id", this.responseId);
		trans.put("module_id", this.getKey());
		trans.put("application_id", this.appid);
		trans.put("payment_type", this.type);
		trans.put("source", this.source.getMsisdn());
		trans.put("destination", this.destination.getMsisdn());
		trans.put("payment_data", this.data);
		if (trans.containsKey("request_date"))
			trans.put("request_date", dfLifetime.format(this.startDate));
		if (trans.containsKey("response_date"))
			trans.put("response_date", dfLifetime.format(this.endDate));
		trans.put("client_address", this.getRequestAddress());
		// trans.put("destination", this.destination);
		return trans;
	}

	protected Transaction() {
		super();
	}

	public static Transaction deserialize(String v) {
		Transaction ret = new Transaction();
		try {
			InputStream bInp = new ByteArrayInputStream(Base64.decode(v));
			ObjectInputStream o;
			o = new ObjectInputStream(bInp);
			ret = (Transaction) o.readObject();
		} catch (IOException e) {
			return null;
		} catch (ClassNotFoundException e) {
			return null;
		}
		return ret;
	}

	public String previous(Response ret) {
		DataRow row = db
				.QueryDataRow(
						"SELECT P.STATUS,H.REFERENCEID FROM TRANSACTION_RESPONSE P RIGHT JOIN TRANSACTION_RECEIVED H ON H.REFERENCEID=P.REFERENCEID WHERE APPID=? AND H.REQUESTID=?",
						this.appid, this.requestId);
		if (row.size() > 0) {
			ret.put("previous", row.getString("REFERENCEID"));
			if (row.getString("STATUS").isEmpty()) {
				ret.put("pending", true);
			}
		}
		return ret.containsKey("previous") ? ret.get("previous").toString() : "";
	}

	public int getRemainingLock() {
		return remainingLock;
	}

}

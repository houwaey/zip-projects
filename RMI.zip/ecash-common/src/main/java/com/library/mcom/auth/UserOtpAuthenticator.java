package com.library.mcom.auth;

import com.library.mcom.arch.Transaction;
import com.library.mcom.arch.auth.AuthType;
import com.library.mcom.arch.auth.Authenticator;

@SuppressWarnings("serial")
public class UserOtpAuthenticator extends Authenticator {

	public UserOtpAuthenticator(Transaction t, String value) {
		super(t);
		// TODO Auto-generated constructor stub
	}

	@Override
	public AuthType getType() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean valid() {
		// TODO Auto-generated method stub
		return false;
	}

}

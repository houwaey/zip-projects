package com.library.mcom.common;

import java.util.LinkedHashMap;
import java.util.Map;

import com.library.jdbc.database.DataRow;
import com.library.jdbc.database.DbWrapper;
import com.library.jdbc.database.DbWrapperFactory;
import com.library.mcom.arch.AccountStatus;
import com.library.mcom.arch.Audit;
import com.library.mcom.arch.Network;
import com.library.mcom.arch.Transaction;
import com.library.mcom.util.Query;
import com.library.util.Constant;

public class McomSubscriber extends com.library.mcom.arch.McomSubscriber {

	private static final long serialVersionUID = 1L;
	private static DbWrapper db = DbWrapperFactory.getDb();

	public McomSubscriber(String msisdnOrAlias) {
		super(msisdnOrAlias);
	}

	private McomSubscriber() {
		super(null);
	}

	@Override
	public boolean exists() {
		if (this.id != -1) {
			this.wallet = new Wallet(this);
			((Wallet) this.wallet).refresh();
			return true;
		}
		DataRow r = db.QueryDataRow(Query.SELECT_MCOM, db.getCrypt(), db.getCrypt(), this.msisdn == null ? ""
				: this.msisdn.toString(), this.alias, db.getCrypt());
		if (r != null && r.size() > 0) {
			this.email = r.getString("EMAIL");
			this.alias = r.getString("ALIAS");
			this.id = r.getInteger("ID");
			this.language = r.getString("LANGUAGE");
			this.locked = r.getString("LOCKED").equals("YES");
			this.msisdn = r.getString("MOBILENUMBER");
			this.network = new Network(r.getString("NETWORK"));
			this.status = AccountStatus.fromString(r.getString("STATUS"));
			this.type = r.getString("TYPE");
			this.wallet = new Wallet(this);
			((Wallet) this.wallet).refresh();

			r.keySet().forEach(key -> {
				this.put(key.toLowerCase(), r.getString(key));
			});

			Map<String, String> subscriber = new LinkedHashMap<String, String>();
			subscriber.put("language", this.language);
			subscriber.put("email", this.email);
			subscriber.put("msisdn", this.msisdn);
			this.put("subscriber", subscriber);
			this.put("pockets", ((Wallet) this.wallet).serialize());
		}
		return r != null && r.size() > 0;
	}

	@Override
	public boolean activate(Audit audit) {
		StringBuilder q = new StringBuilder(Query.BEGIN);
		q.append(Query.UPDATE_MCOM_ACCT_STATUS);
		q.append(Query.INSERT_TRANS_AUDIT);
		q.append(Query.END);
		return db.QueryUpdate(q.toString(), AccountStatus.ACTIVE.value(), this.id, audit.getRefId(), audit.getUser(),
				audit.getApplication(), audit.getEntity(), audit.getKey(), audit.getRemarks(), 0) > 0;
	}

	@Override
	public boolean terminate(Audit audit) {
		StringBuilder q = new StringBuilder(Query.BEGIN);
		q.append(Query.UPDATE_MCOM_ACCT_STATUS);
		q.append(Query.INSERT_TRANS_AUDIT);
		q.append(Query.END);
		return db.QueryUpdate(q.toString(), AccountStatus.TERMINATED.value(), this.id, audit.getRefId(),
				audit.getUser(), audit.getApplication(), audit.getEntity(), audit.getKey(), audit.getRemarks(), 0) > 0;
	}

	@Override
	public boolean lock(Audit audit) {
		StringBuilder q = new StringBuilder(Query.BEGIN);
		q.append(Query.UPDATE_MCOM_LOCK_STATUS);
		q.append(Query.INSERT_TRANS_AUDIT);
		q.append(Query.END);
		return db.QueryUpdate(q.toString(), Constant.YES, this.id, audit.getRefId(), audit.getUser(),
				audit.getApplication(), audit.getEntity(), audit.getKey(), audit.getRemarks(), 0) > 0;
	}

	@Override
	public boolean unlock(Audit audit) {
		StringBuilder q = new StringBuilder(Query.BEGIN);
		q.append(Query.UPDATE_MCOM_LOCK_STATUS);
		q.append(Query.INSERT_TRANS_AUDIT);
		q.append(Query.END);
		return db.QueryUpdate(q.toString(), Constant.NO, this.id, audit.getRefId(), audit.getUser(),
				audit.getApplication(), audit.getEntity(), audit.getKey(), audit.getRemarks(), 0) > 0;
	}
	
	@Override
	public boolean execute(Transaction trans) {
		return false;
	}

	public static McomSubscriber from(String emailOrMobile) {
		McomSubscriber ret = null;
		DataRow r = db.QueryDataRow(Query.SELECT_MCOM_BY_EMAILMSISDN, db.getCrypt(), db.getCrypt(), emailOrMobile);
		if (r.size() > 0) {
			ret = new McomSubscriber(r.getString("ALIAS"));
			ret.email = r.getString("EMAIL");
			ret.alias = r.getString("ALIAS");
			ret.id = r.getInteger("ID");
			ret.language = r.getString("LANGUAGE");
			ret.locked = r.getString("LOCKED").equals("YES");
			ret.msisdn = r.getString("MOBILENUMBER");
			ret.network = new Network(r.getString("NETWORK"));
			ret.status = AccountStatus.fromString(r.getString("STATUS"));
			ret.type = r.getString("TYPE");
			ret.wallet = new Wallet(ret);
			((Wallet) ret.wallet).refresh();

			for (String key : r.keySet()) {
				ret.put(key.toLowerCase(), r.getString(key));
			}

			Map<String, String> subscriber = new LinkedHashMap<String, String>();
			subscriber.put("language", ret.language);
			subscriber.put("email", ret.email);
			subscriber.put("msisdn", ret.msisdn);
			ret.put("subscriber", subscriber);
			ret.put("pockets", ((Wallet) ret.wallet).serialize());
		}
		return ret;
	}

	public static McomSubscriber from(int id) {
		McomSubscriber ret = null;
		DataRow r = db.QueryDataRow(Query.SELECT_MCOM_BY_ID, db.getCrypt(), db.getCrypt(), id);
		if (r.size() > 0) {
			ret = new McomSubscriber(r.getString("ALIAS"));
			ret.email = r.getString("EMAIL");
			ret.alias = r.getString("ALIAS");
			ret.id = r.getInteger("ID");
			ret.language = r.getString("LANGUAGE");
			ret.locked = r.getString("LOCKED").equals("YES");
			ret.msisdn = r.getString("MOBILENUMBER");
			ret.network = new Network(r.getString("NETWORK"));
			ret.status = AccountStatus.fromString(r.getString("STATUS"));
			ret.type = r.getString("TYPE");
			ret.wallet = new Wallet(ret);
			((Wallet) ret.wallet).refresh();

			for (String key : r.keySet()) {
				ret.put(key.toLowerCase(), r.getString(key));
			}

			Map<String, String> subscriber = new LinkedHashMap<String, String>();
			subscriber.put("language", ret.language);
			subscriber.put("email", ret.email);
			subscriber.put("msisdn", ret.msisdn);
			ret.put("subscriber", subscriber);
			ret.put("pockets", ((Wallet) ret.wallet).serialize());
		}
		return ret;
	}

}

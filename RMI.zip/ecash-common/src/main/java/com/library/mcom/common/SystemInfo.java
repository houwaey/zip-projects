package com.library.mcom.common;

public class SystemInfo {
	
	public static final String PROP_COUNTRY_CODE = "";
	
	public static final String getTransId(String prefix) {
		return "";
	}
	
	public static final String getProperty(String name) {
		return "";
	}
	
	public static final String getProperty(String name, String defaultValue) {
		return "";
	}

}
 
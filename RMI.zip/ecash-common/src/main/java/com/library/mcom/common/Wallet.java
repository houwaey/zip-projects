package com.library.mcom.common;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.library.jdbc.database.DataRowCollection;
import com.library.jdbc.database.DbWrapper;
import com.library.jdbc.database.DbWrapperFactory;
import com.library.mcom.util.Query;

public class Wallet extends com.library.mcom.arch.Wallet {
	
	private static final long serialVersionUID = 1L;
	private DbWrapper db = DbWrapperFactory.getDb();
	private boolean refreshed = true;

	protected Wallet(McomSubscriber owner) {
		super(owner);
	}

	public void refresh() {
		refreshed = true;
		DataRowCollection rows = db.QueryDataRows(Query.SELECT_ACCT_BALANCE, db.getCrypt(), this.owner.getMsisdn());
		if (rows != null && rows.size() > 0) {
			rows.forEach(r -> {
				int walletid = r.getInteger("WALLETID");
				int id = Math.abs(walletid);
				if (this.containsKey(id) || id == 99999) {
					id = id == 99999 ? 0 : id;
					if (refreshed) {
						this.get(id).setAvailableBalance(r.getLong("AMOUNT"));
					} else {
						this.get(id).setCurrentBalance(r.getLong("AMOUNT") + this.get(id).getAvailableBalance());
					}

				} else {
					refreshed = false;
					Pocket p = new Pocket(id, "", r.getLong("AMOUNT"));
					p.setLastUsed(r.getTimestamp("LASTUSED"));
					this.put(id, p);
				}
			});
		}
	}

	@SuppressWarnings("rawtypes")
	public List<Map> serialize() {
		List<Map> pockets = new ArrayList<Map>();
		this.values().forEach(p -> {
			Pocket pocket = (Pocket) p;
			pockets.add(pocket.serialize());
		});
		return pockets;
	}

}

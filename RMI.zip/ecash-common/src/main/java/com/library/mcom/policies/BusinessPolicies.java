package com.library.mcom.policies;

import java.io.File;
import java.io.FileFilter;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import com.library.common.Log;
import com.library.common.Util;
import com.library.jdbc.database.DataRow;
import com.library.jdbc.database.DataRowCollection;
import com.library.jdbc.database.DbWrapper;
import com.library.jdbc.database.DbWrapperFactory;
import com.library.mcom.arch.Transaction;
import com.library.mcom.arch.acl.Node;
import com.library.mcom.arch.aml.BreachListener;
import com.library.mcom.arch.aml.Rule;
import com.library.mcom.arch.aml.Rules;

public class BusinessPolicies extends Rules {

	private static final long serialVersionUID = 1L;
	private static URLClassLoader loader = null;
	private DbWrapper db = DbWrapperFactory.getDb();

	static {

		try {
			File[] pluginfiles = (new File(Util.getWorkingDirectory() + "/ecash/policies/"))
					.listFiles(new FileFilter() {
						@Override
						public boolean accept(File paramFile) {
							Log.server(paramFile.getName() + " is  accepted = "
									+ paramFile.getName().matches("(?i).*\\.jar$"));
							return paramFile.isFile() && paramFile.getName().matches("(?i).*\\.jar$");
						}
					});
			List<URL> pluginurls = new ArrayList<URL>();
			for (File f : pluginfiles) {
				pluginurls.add(f.toURI().toURL());
			}
			if (pluginurls.size() > 0) {
				try {
					loader = new URLClassLoader(pluginurls.toArray(new URL[pluginurls.size()]), Thread.currentThread()
							.getContextClassLoader());
					Thread.currentThread().setContextClassLoader(loader);
				} catch (Exception e) {
					Log.server(e);
				}
			}
		} catch (Exception e) {
			Log.server(e);
		}
	}

	public BusinessPolicies() {
		super(null);
	}

	public BusinessPolicies(Transaction t, BreachListener handler) {
		super(t);
		this.handler = handler;
		DataRowCollection rows = db.QueryDataRows(
				"SELECT  A.* FROM SETTINGS_BUSINESS A WHERE KEY IN ('*',?) AND (ACCOUNT IN ('*',?,?) OR ACCOUNT LIKE '"
						+ t.getSource().getNetwork().toString()
						+ "%') AND ACCOUNTTYPE IN (? , '*')  ORDER BY ACCOUNT ASC", t.getKey(), t.getSource()
						.getNetwork().get(0), t.getSource().getMsisdn(), t.getSource().getType());

		if (rows != null && rows.size() > 0) {
			Hashtable<String, DataRow> unique = new Hashtable<String, DataRow>();
			rows.forEach(r -> {
				unique.put(r.getString("INTERFACE"), r);
			});
			unique.values().forEach(r -> {
				try {
					Rule rule = (Rule) Class.forName(r.getString("INTERFACE"), true, loader).newInstance();
					rule.setAccount(new Node(t.getSource().getMsisdn(), t.getSource().getNetwork().toString()));
					rule.setKey(t.getKey());
					rule.setValue(r.getString("VALUE"));
					rule.setDescription(r.getString("DESCRIPTION"));
					rule.setTransaction(t);
					Log.server("Implementing Policy: " + r.getString("INTERFACE"));
					this.add(rule);
				} catch (Exception e) {
					Log.server(e);
				}
			});
			this.monitor();
		}
	}

}

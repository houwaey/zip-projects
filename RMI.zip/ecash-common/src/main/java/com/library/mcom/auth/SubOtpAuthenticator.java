package com.library.mcom.auth;

import com.library.jdbc.database.DbWrapper;
import com.library.jdbc.database.DbWrapperFactory;
import com.library.mcom.arch.Transaction;
import com.library.mcom.arch.auth.AuthType;
import com.library.mcom.arch.auth.Authenticator;

@SuppressWarnings("serial")
public class SubOtpAuthenticator extends Authenticator {

	private DbWrapper db = DbWrapperFactory.getDb();
	private String value;

	public SubOtpAuthenticator(Transaction t, String value) {
		super(t);
		this.value = value;
	}

	@Override
	public AuthType getType() {
		return AuthType.OTP;
	}

	@Override
	public boolean valid() {
		return db.QueryScalar(
				"SELECT COUNT(1) FROM ACCOUNT_INFO_EXTENDED WHERE MOBILENUMBER=? AND OTP = ENCRYPT(?,?,MOBILENUMBER) ",
				0, this.trans.getSource().getMsisdn(), this.value, db.getCrypt()) > 0;
	}

}

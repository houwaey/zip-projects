package com.library.mcom.common;

import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

import com.library.common.LongUtil;

public class Pocket extends com.library.mcom.arch.Pocket {

	private static final long serialVersionUID = 1L;
	SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	public Pocket(int walletid, String name, Long availableBalance) {
		super(walletid, name, availableBalance);
	}

	public Map<String, String> serialize() {
		Map<String, String> ret = new HashMap<String, String>();
		ret.put("pocket_id", String.valueOf(this.getId()));
		ret.put("pocket_name", this.getName());
		ret.put("current_balance", LongUtil.toString(this.getCurrentBalance()));
		ret.put("available_balance", LongUtil.toString(this.getAvailableBalance()));
		ret.put("last_used", formatter.format(this.getLastUsed()));
		return ret;
	}
}
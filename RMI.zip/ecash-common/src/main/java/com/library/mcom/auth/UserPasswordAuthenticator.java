package com.library.mcom.auth;

import com.library.jdbc.database.DbWrapper;
import com.library.jdbc.database.DbWrapperFactory;
import com.library.mcom.arch.Transaction;
import com.library.mcom.arch.auth.AuthType;
import com.library.mcom.arch.auth.Authenticator;

@SuppressWarnings("serial")
public class UserPasswordAuthenticator extends Authenticator {

	private DbWrapper db = DbWrapperFactory.getDb();
	private String value;

	public UserPasswordAuthenticator(Transaction t, String value) {
		super(t);
		this.value = value;
	}

	@Override
	public AuthType getType() {
		return AuthType.PASSWORD;
	}

	@Override
	public boolean valid() {
		return db.QueryScalar(
				"SELECT COUNT(1) FROM ACCOUNT_USERS WHERE UPPER(USERNAME)=UPPER(?) AND PASSWORD=ENCRYPT(?,?,USERNAME)",
				0, this.trans.getUser().getUsername(), this.value, db.getCrypt()) > 0;
	}

}

package com.library.mcom.auth;

import com.library.mcom.arch.Transaction;
import com.library.mcom.arch.auth.AuthType;
import com.library.mcom.arch.auth.Authenticator;

@SuppressWarnings("serial")
public class BypassAuthenticator extends Authenticator {

	public BypassAuthenticator(Transaction t) {
		super(t);
	}

	@Override
	public AuthType getType() {
		return null;
	}

	@Override
	public boolean valid() {
		return true;
	}

}

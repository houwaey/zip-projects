package com.library.mcom.auth;

import com.library.jdbc.database.DbWrapper;
import com.library.jdbc.database.DbWrapperFactory;
import com.library.mcom.arch.Transaction;
import com.library.mcom.arch.auth.AuthType;
import com.library.mcom.arch.auth.Authenticator;

@SuppressWarnings("serial")
public class SubPasswordAuthenticator extends Authenticator {

	private DbWrapper db = DbWrapperFactory.getDb();
	private String value;

	public SubPasswordAuthenticator(Transaction t, String value) {
		super(t);
		this.value = value;
	}

	@Override
	public AuthType getType() {
		return null;
	}

	@Override
	public boolean valid() {
		return db.QueryScalar("SELECT COUNT(1) FROM ACCOUNT_INFO WHERE ID=? AND PASSWORD = ENCRYPT(?,?,MOBILENUMBER) ",
				0, this.trans.getSource().getId(), this.value, db.getCrypt()) > 0;
	}

}

package com.library.mcom.util;

public class Query {

	public static final String LOCALPATTERN = "SELECT '(?:\\+|0{1,2})?(?<countrycode>' || COUNTRYCODE || ')?(?<msisdn>' || NDC || '\\d{' || (MOBILELENGTH-LENGTH(NDC)) || '})' FROM SETTINGS_GSMNETWORK INNER JOIN SETTINGS_NDCLIST ON SETTINGS_GSMNETWORK.ID = GSMNETWORKID WHERE SETTINGS_GSMNETWORK.STATUS = 1 AND SETTINGS_NDCLIST.STATUS = 1 AND OTHERNET = 0 AND COUNTRYCODE = (SELECT COUNTRYCODE FROM SETTINGS_SYSTEM)";

	public static final String LOCALNETPATTERN = "SELECT '(?:\\+|0{1,2})?(?<countrycode>' || COUNTRYCODE || ')?(?<msisdn>' || NDC || '\\d{' || (MOBILELENGTH-LENGTH(NDC)) || '})' FROM SETTINGS_GSMNETWORK INNER JOIN SETTINGS_NDCLIST ON SETTINGS_GSMNETWORK.ID = GSMNETWORKID WHERE SETTINGS_GSMNETWORK.STATUS = 1 AND SETTINGS_NDCLIST.STATUS = 1 AND OTHERNET = 1 AND COUNTRYCODE = (SELECT COUNTRYCODE FROM SETTINGS_SYSTEM)";

	public static final String ROAMINGPATTERN = "SELECT '(?:\\+|00)?(?<countrycode>' || COUNTRYCODE || ')(?<msisdn>' || NDC || '\\d{' || (MOBILELENGTH-LENGTH(NDC)) || '})' FROM SETTINGS_GSMNETWORK INNER JOIN SETTINGS_NDCLIST ON SETTINGS_GSMNETWORK.ID = GSMNETWORKID WHERE SETTINGS_GSMNETWORK.STATUS = 1 AND SETTINGS_NDCLIST.STATUS = 1 AND OTHERNET = 0 AND COUNTRYCODE <> (SELECT COUNTRYCODE FROM SETTINGS_SYSTEM)";

	public static final String ROAMINGNETPATTERN = "SELECT '(?:\\+|00)?(?<countrycode>' || COUNTRYCODE || ')(?<msisdn>' || NDC || '\\d{' || (MOBILELENGTH-LENGTH(NDC)) || '})' FROM SETTINGS_GSMNETWORK INNER JOIN SETTINGS_NDCLIST ON SETTINGS_GSMNETWORK.ID = GSMNETWORKID WHERE SETTINGS_GSMNETWORK.STATUS = 1 AND SETTINGS_NDCLIST.STATUS = 1 AND OTHERNET = 1 AND COUNTRYCODE <> (SELECT COUNTRYCODE FROM SETTINGS_SYSTEM)";

	public static final String SELECT_ACCT_BALANCE = "SELECT MOBILENUMBER, WALLETID, DECRYPT(AMOUNT,?,MOBILENUMBER) AMOUNT, LASTUSED "
			+ "FROM ACCOUNT_BALANCE CS " + "WHERE MOBILENUMBER = ? " + "ORDER BY WALLETID DESC";

	/* ------------------------ McomSubscriber ----------------------------- */
	public static final String BEGIN = "BEGIN \n";
	public static final String END = "END;";

	public static final String UPDATE_MCOM_ACCT_STATUS = "UPDATE ACCOUNT_INFO SET STATUS=? WHERE ID=?;\n";
	public static final String UPDATE_MCOM_LOCK_STATUS = "UPDATE ACCOUNT_INFO SET LOCKED=? WHERE ID=?;\n";
	public static final String INSERT_TRANS_AUDIT = "INSERT INTO TRANSACTION_AUDIT(REFERENCEID,USERID,APPID,ENTITY,KEY,REMARKS,STATUS) VALUES(?,?,?,?,?,?,?);\n";
	
	public static final String SELECT_MCOM =
			"SELECT INFO.*, DECRYPT(INFO.ALIAS,?,MOBILENUMBER) ALIAS, DECRYPT(INFO.TYPE,?,MOBILENUMBER) TYPE FROM ACCOUNT_INFO INFO WHERE MOBILENUMBER=? OR ALIAS=ENCRYPT(?,?,MOBILENUMBER)";
	public static final String SELECT_MCOM_BY_EMAILMSISDN =
			"SELECT INFO.*, DECRYPT(INFO.ALIAS,?,MOBILENUMBER) ALIAS, DECRYPT(INFO.TYPE,?,MOBILENUMBER) TYPE FROM ACCOUNT_INFO INFO WHERE ? IN (EMAIL,MOBILENUMBER)";
	public static final String SELECT_MCOM_BY_ID =
			"SELECT INFO.*, DECRYPT(INFO.ALIAS,?,MOBILENUMBER) ALIAS, DECRYPT(INFO.TYPE,?,MOBILENUMBER) TYPE FROM ACCOUNT_INFO INFO WHERE ID=?";


	
	public static final String sqlCredit =    
			"    UPDATE ACCOUNT_BALANCE SET AMOUNT = ENCRYPT(NVL(DECRYPT(AMOUNT,vCRYPT,MOBILENUMBER),0) + ? ,vCRYPT,MOBILENUMBER) WHERE MOBILENUMBER = ? AND WALLETID = ? RETURNING DECRYPT(AMOUNT,vCRYPT,MOBILENUMBER) INTO vTEMPAFTER;\n" +
			"    vSTATUS := SQL%ROWCOUNT; \n" +
			"    vLEVEL := vLEVEL + 1;\n" +
			"    IF NOT vSTATUS = 1 THEN\n" +
			"        RAISE FAILED_TRANS;\n" +
			"    END IF;\n" +   
			"    vTEMPBEFORE := vTEMPAFTER - ?;\n" + 
			"    INSERT INTO TRANSACTION_PARTICULARS(TRANSID, REFERENCEID, TYPE, MOBILENUMBER, CREDIT, DEBIT, TIMESTAMP, REMARKS, BALANCEBEFORE, BALANCEAFTER, ALIAS, GLID, WALLETID,ACCOUNTTYPE)\n" +
			"    VALUES(vTRANSID, vREFID, ? , ?, ?, 0, SYSDATE, ?, vTEMPBEFORE, vTEMPAFTER, ?, ?, ?,?);\n" +
			"    vSTATUS := SQL%ROWCOUNT; \n" +
			"    vLEVEL := vLEVEL + 1;\n" +
			"    IF vSTATUS < 1 THEN\n" +
			"        RAISE FAILED_TRANS;\n" +
			"    END IF;\n";
	
	public static final String sqlDebit = 
			"    UPDATE ACCOUNT_BALANCE SET AMOUNT = ENCRYPT(NVL(DECRYPT(AMOUNT,vCRYPT,MOBILENUMBER),0) - ?,vCRYPT,MOBILENUMBER) WHERE MOBILENUMBER = ? AND DECRYPT(AMOUNT,vCRYPT,MOBILENUMBER) >= ? AND WALLETID = ? RETURNING DECRYPT(AMOUNT,vCRYPT,MOBILENUMBER) INTO vTEMPAFTER;\n" +
					"    vSTATUS := SQL%ROWCOUNT; \n" +
					"    vLEVEL := vLEVEL + 1;\n" +
					"    IF NOT vSTATUS = 1 THEN\n" +
					"        RAISE FAILED_TRANS;\n" +
					"    END IF;\n" + 
					"    vTEMPBEFORE := vTEMPAFTER + ?;\n" + 
					"    INSERT INTO TRANSACTION_PARTICULARS(TRANSID, REFERENCEID, TYPE, MOBILENUMBER, CREDIT, DEBIT, TIMESTAMP, REMARKS, BALANCEBEFORE, BALANCEAFTER, ALIAS, GLID, WALLETID,ACCOUNTTYPE)\n" +
					"    VALUES(vTRANSID, vREFID, ?, ?, 0, ?, SYSDATE, ?, vTEMPBEFORE, vTEMPAFTER, ?, ?, ?,?);\n" +
					"    vSTATUS := SQL%ROWCOUNT; \n" +
					"    vLEVEL := vLEVEL + 1;\n" +
					"    IF vSTATUS < 1 THEN\n" +
					"        RAISE FAILED_TRANS;\n" +
					"    END IF;\n";
	
	public static final String sqlTail = 
			"    INSERT INTO TRANSACTION_DATA(ID, REFERENCEID, KEY, FRMOBILENUMBER, TOMOBILENUMBER, AMOUNT, TIMESTAMP, EXTENDEDDATA, REMARKS, FRALIAS, TOALIAS,MAINWALLET,SRCBALANCEBEFORE,SRCBALANCEAFTER,DESTBALANCEBEFORE,DESTBALANCEAFTER)\n" +
			"         VALUES (vTRANSID, vREFID, vKEY, vFROM, ?, ?, SYSDATE, vEXTDATA1, vEXTDATA2, ?, ?,vWALLET,vORIGBEFORE,vORIGAFTER,vDESTBEFORE,vDESTAFTER);\n" +
			"        vSTATUS := SQL%ROWCOUNT; \n" +
			"        vLEVEL := vLEVEL + 1;\n" +
			"        IF NOT vSTATUS = 1 THEN\n" +
			"            RAISE FAILED_TRANS;\n" +
			"        END IF;\n" +  
			"EXCEPTION WHEN OTHERS THEN\n" +
			"  ROLLBACK;\n" +
			"  RAISE;\n" +
			"END;";
	
	
	public static final String sqlheaderwallet = 
			"DECLARE\n" +
			"    vTRANSID            NUMBER;\n" +
			"    vREFID              VARCHAR(30);\n" +
			"    vKEY                VARCHAR(30);\n" +
			"    vFROM               VARCHAR2(20);\n" +
			"    vTEMPBEFORE         NUMBER;\n" +
			"    vTEMPAFTER          NUMBER;\n" +
			"    vORIGBEFORE         NUMBER;\n" +
			"    vORIGAFTER          NUMBER;\n" +
			"    vDESTBEFORE         NUMBER;\n" +
			"    vDESTAFTER          NUMBER;\n" +
			"    vORIGSPLITBEFORE         NUMBER;\n" +
			"    vORIGSPLITAFTER          NUMBER;\n" + 
			"    vDESTSPLITBEFORE         NUMBER;\n" +
			"    vDESTSPLITAFTER          NUMBER;\n" +
			"    vEXTDATA1           VARCHAR2(300);\n" +
			"    vEXTDATA2           VARCHAR2(300);\n" +
			"    vCRYPT              VARCHAR(50);\n" +
			"    vSTATUS             NUMBER;\n" +
			"    vWALLET             INTEGER;\n" +
			"    vLEVEL              INTEGER;\n" +
			"    FAILED_TRANS        EXCEPTION;\n" +
			"BEGIN\n" +
			"    vREFID              := ?;\n" +
			"    vKEY                := ?;\n" +
			"    vFROM               := ?;\n" +
			"    vEXTDATA1           := ?;\n" +
			"    vEXTDATA2           := ?;\n" +
			"    vCRYPT              := ?;\n" +
			"    vWALLET             := ?;\n" + //Add wallet to transact
			"    vLEVEL              := 0;\n" +
			"    SELECT SEQTBLTRANSACTIONS.NEXTVAL INTO vTRANSID FROM DUAL;\n";
	
	public static final String sqlheaderwalletadj = 
			"DECLARE\n" +
			"    vTRANSID            NUMBER;\n" +
			"    vREFID              VARCHAR(30);\n" +
			"    vKEY                VARCHAR(30);\n" +
			"    vFROM               VARCHAR2(20);\n" +
			"    vTEMPBEFORE         NUMBER;\n" +
			"    vTEMPAFTER          NUMBER;\n" +
			"    vORIGBEFORE         NUMBER;\n" +
			"    vORIGAFTER          NUMBER;\n" +
			"    vDESTBEFORE         NUMBER;\n" +
			"    vDESTAFTER          NUMBER;\n" +
			"    vEXTDATA1           VARCHAR2(300);\n" +
			"    vEXTDATA2           VARCHAR2(300);\n" +
			"    vCRYPT              VARCHAR(50);\n" +
			"    vSTATUS             NUMBER;\n" +
			"    vWALLET             INTEGER;\n" +
			"    vLEVEL              INTEGER;\n" +
			"    FAILED_TRANS        EXCEPTION;\n" +
			"BEGIN\n" +
			"    vREFID              := ?;\n" +
			"    vKEY                := ?;\n" +
			"    vFROM               := ?;\n" +
			"    vEXTDATA1           := ?;\n" +
			"    vEXTDATA2           := ?;\n" +
			"    vCRYPT              := ?;\n" +
			"    vWALLET             := ?;\n" + //Add wallet to transact
			"    vLEVEL              := 0;\n" ;
	
	
	public static final String sqlheaderrollback = 
			"DECLARE\n" +
			"    vTRANSID            NUMBER;\n" +
			"    vREFID              VARCHAR(30);\n" +
			"    vKEY                VARCHAR(30);\n" +
			"    vFROM               VARCHAR2(20);\n" +
			"    vTEMPBEFORE         NUMBER;\n" +
			"    vTEMPAFTER          NUMBER;\n" +
			"    vORIGBEFORE         NUMBER;\n" +
			"    vORIGAFTER          NUMBER;\n" +
			"    vDESTBEFORE         NUMBER;\n" +
			"    vDESTAFTER          NUMBER;\n" +
			"    vEXTDATA1           VARCHAR2(300);\n" +
			"    vEXTDATA2           VARCHAR2(300);\n" +
			"    vCRYPT              VARCHAR(50);\n" +
			"    vSTATUS             NUMBER;\n" +
			"    vWALLET             INTEGER;\n" +
			"    vLEVEL              INTEGER;\n" +
		
			"    vORIGSTART	         NUMBER;\n" +
			"    vDESTSTART          NUMBER;\n" +
			"    FAILED_TRANS        EXCEPTION;\n" +
			"BEGIN\n" +
			"    vREFID              := ?;\n" +
			"    vKEY                := ?;\n" +
			"    vFROM               := ?;\n" +
			"    vEXTDATA1           := ?;\n" +	
			"    vEXTDATA2           := ?;\n" +
			"    vCRYPT              := ?;\n" +
			"    vWALLET             := ?;\n" + //Add wallet to transact
			"    vLEVEL              := 0;\n" +
			"    SELECT ID INTO vTRANSID FROM TRANSACTION_DATA WHERE REFERENCEID=vREFID;\n";
			
	
	
	public static final String sqlTailadjust = 
			"        vSTATUS := SQL%ROWCOUNT; \n" +
			"        vLEVEL := vLEVEL + 1;\n" +
			"        IF NOT vSTATUS = 1 THEN\n" +
			"            RAISE FAILED_TRANS;\n" +
			"        END IF;\n" +  
			"EXCEPTION WHEN OTHERS THEN\n" +
			"  ROLLBACK;\n" +
			"  RAISE;\n" +
			"END;";
	
	public static final String sqlTailrollback = 
			"UPDATE TRANSACTION_DATA SET VOIDID=vREFID,DESTBALANCEBEFORE=vDESTAFTER, SRCBALANCEBEFORE=vORIGAFTER,SRCBALANCEAFTER=vORIGAFTER,DESTBALANCEAFTER=vDESTAFTER WHERE REFERENCEID = vREFID;\n"+
			"        vSTATUS := SQL%ROWCOUNT; \n" +
			"        vLEVEL := vLEVEL + 1;\n" +
			"        IF NOT vSTATUS = 1 THEN\n" +
			"            RAISE FAILED_TRANS;\n" +
			"        END IF;\n" +  
			"EXCEPTION WHEN OTHERS THEN\n" +
			"  ROLLBACK;\n" +
			"  RAISE;\n" +
			"END;";

}
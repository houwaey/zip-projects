package com.ecash.rmi.server;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

import com.ecash.rmi.dto.SSLFile;
import com.ecash.rmi.impl.SubscriberInfoImpl;
import com.ecash.rmi.ssl.SslClientSocketFactory;
import com.ecash.rmi.ssl.SslServerSocketFactory;
import com.ecash.rmi.util.Constant;
import com.library.common.EncryptedProperties;
import com.library.common.Log;
import com.library.common.Util;

public class RMIServer {

	public static void main(String[] args) {
		EncryptedProperties certProp;
		try {
			Log.server("E-Cash RMI Server started...");
			certProp = new EncryptedProperties(Constant.PROP_CERT);
			
			/* =============================== SSL Security Configuration ============================== */
			SslServerSocketFactory ssf = new SslServerSocketFactory(
					new SSLFile(
							Util.getWorkingDirectory() + certProp.getProperty(Constant.PROP_PARAM_SERVER_JKS_FILEPATH),
							certProp.getProperty(Constant.PROP_PARAM_SERVER_JKS_PASSWORD)),
					new SSLFile(
							Util.getWorkingDirectory() + certProp.getProperty(Constant.PROP_PARAM_SERVER_TS_FILEPATH),
							certProp.getProperty(Constant.PROP_PARAM_SERVER_TS_PASSWORD)));
			SslClientSocketFactory csf = new SslClientSocketFactory(
					new SSLFile(
							Util.getWorkingDirectory() + certProp.getProperty(Constant.PROP_PARAM_CLIENT_JKS_FILEPATH),
							certProp.getProperty(Constant.PROP_PARAM_CLIENT_JKS_PASSWORD)),
					new SSLFile(
							Util.getWorkingDirectory() + certProp.getProperty(Constant.PROP_PARAM_CLIENT_TS_FILEPATH),
							certProp.getProperty(Constant.PROP_PARAM_CLIENT_TS_PASSWORD)));
			/* =============================== SSL Security Configuration ============================== */
			
			Registry registry = LocateRegistry.createRegistry(4000, csf, ssf);
			Log.server("E-Cash RMI Registry created...");

			registry.rebind("SubscriberInfo", UnicastRemoteObject.exportObject(new SubscriberInfoImpl(), 0));
			Log.server("PeerServer bound in registry...");
		} catch (Exception e) {
			Log.server(e);
			System.exit(1);
		}
	}

}

package com.ecash.rmi.impl;

import com.ecash.rmi.interfaces.SubscriberInfo;
import com.library.mcom.common.Subscriber;

public class SubscriberInfoImpl implements SubscriberInfo {
	
	private Subscriber subscriber;
	
	@Override
	public boolean isLocal() {
		return subscriber.isLocal();
	}

	@Override
	public boolean isRoaming() {
		return subscriber.isRoaming();
	}

	@Override
	public boolean isOthernet() {
		return subscriber.isOthernet();
	}

	@Override
	public boolean isAlias() {
		return subscriber.isAlias();
	}

	@Override
	public String getMsisdn() {
		return subscriber.getMsisdn();
	}

	@Override
	public void validate(String msisdn) {
		subscriber = new Subscriber(msisdn);
		System.out.println("my msisdn: " + subscriber.getMsisdn());
	}

}

package com.ecash.rmi.util;

import com.library.common.Util;

public class Constant {

	public static final String PROP_CERT = Util.getWorkingDirectory() + "/ext/properties/certificate.properties";
	public static final String DIR_CERT = Util.getWorkingDirectory() + "/ext/cert/";
	
	public static final String PROP_PARAM_SERVER_JKS_FILEPATH = "server_jks_filepath";
	public static final String PROP_PARAM_SERVER_TS_FILEPATH = "server_ts_filepath";
	public static final String PROP_PARAM_CLIENT_JKS_FILEPATH = "client_jks_filepath";
	public static final String PROP_PARAM_CLIENT_TS_FILEPATH = "client_ts_filepath";
	public static final String PROP_PARAM_SERVER_JKS_PASSWORD = "server_jks_password";
	public static final String PROP_PARAM_SERVER_TS_PASSWORD = "server_ts_password";
	public static final String PROP_PARAM_CLIENT_JKS_PASSWORD = "client_jks_password";
	public static final String PROP_PARAM_CLIENT_TS_PASSWORD = "client_ts_password";
	
}

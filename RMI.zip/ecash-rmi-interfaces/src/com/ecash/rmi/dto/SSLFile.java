package com.ecash.rmi.dto;

import java.io.File;

public class SSLFile {

	private String path;
	private File file;
	private String password;

	public SSLFile(String path, String password) {
		super();
		this.file = new File(path);
		this.password = password;
	}
	
	public SSLFile(File file, String password) {
		super();
		this.file = file;
		this.password = password;
	}

	public String getPath() {
		return path;
	}

	public File getFile() {
		return file;
	}

	public String getPassword() {
		return password;
	}
	
}
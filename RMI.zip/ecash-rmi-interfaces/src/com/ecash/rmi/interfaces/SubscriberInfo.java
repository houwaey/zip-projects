package com.ecash.rmi.interfaces;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface SubscriberInfo extends Remote {

	boolean isLocal() throws RemoteException;
	boolean isRoaming() throws RemoteException;
	boolean isOthernet() throws RemoteException;
	boolean isAlias() throws RemoteException;
	String getMsisdn() throws RemoteException;
	void validate(String msisdn) throws RemoteException;
	
}
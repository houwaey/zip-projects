package com.ecash.rmi.client;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

import com.ecash.rmi.dto.SSLFile;
import com.ecash.rmi.interfaces.SubscriberInfo;
import com.ecash.rmi.ssl.SslClientSocketFactory;
import com.ecash.rmi.util.Constant;

public class RMIClient {

	public static void main(String[] args) {
		try {
			
			SslClientSocketFactory csf = new SslClientSocketFactory(
					new SSLFile(
							Constant.PROP_PARAM_CLIENT_JKS_FILENAME,
							Constant.PROP_PARAM_CLIENT_JKS_PASSWORD),
					new SSLFile(
							Constant.PROP_PARAM_CLIENT_TS_FILENAME,
							Constant.PROP_PARAM_CLIENT_TS_PASSWORD));
			Registry registry = LocateRegistry.getRegistry("127.0.0.1", 4000, csf);
			
			SubscriberInfo sInfo = (SubscriberInfo) registry.lookup("SubscriberInfo");
			sInfo.validate("08174471681");
//			System.out.println("msisdn: " + sInfo.getMsisdn());
			
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(1);
		}
	}
	
}

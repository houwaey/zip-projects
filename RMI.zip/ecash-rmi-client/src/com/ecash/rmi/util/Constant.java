package com.ecash.rmi.util;

public class Constant {

	public static final String PROP_CERT = Util.getWorkingDirectory() + "/ext/properties/certificate.properties";
	public static final String DIR_CERT = Util.getWorkingDirectory() + "/cert/";
	
	public static final String PROP_PARAM_CLIENT_JKS_FILENAME = DIR_CERT + "client_20190306.jks";
	public static final String PROP_PARAM_CLIENT_TS_FILENAME  = DIR_CERT + "client_20190306.ts";
	public static final String PROP_PARAM_CLIENT_JKS_PASSWORD = "pa55w0rd";
	public static final String PROP_PARAM_CLIENT_TS_PASSWORD = "pa55w0rd";
	
}
package com.ecash.rmi.util;

import java.io.File;

public class Util {

	public static String getWorkingDirectory() {
		return (new File(System.getProperty("java.class.path").split(":")[0])).getAbsoluteFile().getParentFile()
				.getPath();
	}

}

package com.sigma.util;

public class Constant {

	public static final String ACTIVE = "ACTIVE";
	public static final String INACTIVE = "INACTIVE";
	public static final String LOCKED = "LOCKED";
	
}

package com.sigma.service;

import java.io.Serializable;

import com.sigma.interfaces.Operations;

public interface UserService<T extends Serializable> extends Operations<T> {

}

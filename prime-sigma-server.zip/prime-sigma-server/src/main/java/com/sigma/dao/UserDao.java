package com.sigma.dao;

import java.io.Serializable;

import com.sigma.interfaces.Operations;

public interface UserDao<T extends Serializable> extends Operations<T> {

}

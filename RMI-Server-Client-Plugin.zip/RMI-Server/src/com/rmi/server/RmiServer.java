package com.rmi.server;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;

public class RmiServer {
	
	public static void main(String[] args) throws RemoteException, MalformedURLException {
		System.out.println("RMI Server started...");
		
		try {
			LocateRegistry.createRegistry(1099);
			System.out.println("RMI Registry created.");
		} catch (RemoteException e) {
			System.out.println("RMI Registry already exists.");
		}
		
		UserInfo userInfo = new UserInfo();
		Naming.rebind("UserInfo", userInfo);
		System.out.println("PeerServer bound in registry.");
	}

}
package com.rmi.client;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

import com.rmi.plugin.dto.PersonalInfo;
import com.rmi.plugin.interfaces.IUserInfo;

public class RmiClient {

	public static void main(String[] args) throws MalformedURLException, RemoteException, NotBoundException {
		IUserInfo userInfo = (IUserInfo) Naming.lookup("rmi://localhost/UserInfo");
		
//		PersonalInfo pInfo = new PersonalInfo();
//		pInfo.setId(2);
//		pInfo.setFirstName("Juan");
//		pInfo.setMiddleName("Tamad");
//		pInfo.setLastName("Dela Cruz");
//		userInfo.addInfo(pInfo);
		
		System.out.println(userInfo.getInfo(1));
		System.out.println(userInfo.getAllInfo());
	}
	
}

package com.rmi.server.impl;

import java.rmi.RemoteException;

import com.rmi.plugin.interfaces.IAccountManagement;

public class AccountManagement implements IAccountManagement {

	@Override
	public boolean activate(int arg0) throws RemoteException {
		return true;
	}

	@Override
	public boolean deactivate(int arg0) throws RemoteException {
		return true;
	}

	@Override
	public boolean lock(int arg0) throws RemoteException {
		return true;
	}

	@Override
	public boolean unlock(int arg0) throws RemoteException {
		return true;
	}

	

}

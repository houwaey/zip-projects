package com.rmi.client;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.rmi.NotBoundException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;

import com.rmi.client.ssl.SslClientSocketFactory;
import com.rmi.plugin.interfaces.IAccountManagement;
import com.rmi.plugin.util.Util;

public class RmiClientSSL {

	public static void main(String[] args)
			throws UnrecoverableKeyException, KeyManagementException, FileNotFoundException, NoSuchAlgorithmException,
			CertificateException, KeyStoreException, IOException, NotBoundException {
		//System.setProperty("java.security.policy", "all.policy");
        //System.setSecurityManager(new SecurityManager());
		
		SslClientSocketFactory csf = new SslClientSocketFactory(Util.getWorkingDirectory() + "/cert/client_20190306", "pa55w0rd");
		Registry registry = LocateRegistry.getRegistry("127.0.0.1", 4000, csf);

		IAccountManagement acctMgmt = (IAccountManagement) registry.lookup("AccountManagement");
		System.out.println("activate: " + acctMgmt.activate(1));
		System.out.println("deactivate: " + acctMgmt.deactivate(2));
		System.out.println("lock: " + acctMgmt.lock(3));
		System.out.println("unlock: " + acctMgmt.unlock(4));
	}

}
package com.library.tester;

import java.io.IOException;
import java.io.Serializable;

import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;

import org.omnifaces.cdi.ViewScoped;

@Named
@ViewScoped
public class LoginView implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Inject
	private LoginSession loginSession;
	
	private String username;
	private String password;
	
	public void doLogin() {
		loginSession.setUsername(username);
		loginSession.setPassword(password);
		
		FacesContext context = FacesContext.getCurrentInstance();
		try {
			context.getExternalContext().redirect(context.getExternalContext().getRequestContextPath() + "/anotherPage.xhtml");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}

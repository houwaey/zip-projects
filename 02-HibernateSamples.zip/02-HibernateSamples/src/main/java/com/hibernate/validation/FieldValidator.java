package com.hibernate.validation;

import java.util.ArrayList;
import java.util.List;

import org.springframework.validation.FieldError;

import com.hibernate.common.FieldErrorDto;

public class FieldValidator {

	private List<FieldErrorDto> fieldErrors;;
	
	public FieldValidator(List<FieldError> errors) {
		fieldErrors = new ArrayList<FieldErrorDto>();
		for (FieldError error : errors) {
			fieldErrors.add(new FieldErrorDto(error.getField(), error.getDefaultMessage()));
		}
	}

	public List<FieldErrorDto> getFieldErrors() {
		return fieldErrors;
	}
	
}

package com.hibernate.validation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.hibernate.pojo.WebUserRequest;

public class PasswordMatchesValidator implements ConstraintValidator<PasswordMatches, Object> {

	@Override
	public void initialize(PasswordMatches constraintAnnotation) {

	}

	@Override
	public boolean isValid(Object object, ConstraintValidatorContext context) {
		WebUserRequest user = (WebUserRequest) object;
		return user.getPassword().equals(user.getMatchingPassword());
	}

}
package com.hibernate.service;

import java.io.Serializable;

import com.hibernate.dao.common.Operations;

public interface UserService<T extends Serializable> extends Operations<T> {

}

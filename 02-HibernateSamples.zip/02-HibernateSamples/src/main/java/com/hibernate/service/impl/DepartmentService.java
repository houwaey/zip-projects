package com.hibernate.service.impl;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hibernate.dao.SchoolDao;
import com.hibernate.dao.common.Operations;
import com.hibernate.entity.Department;
import com.hibernate.service.SchoolService;
import com.hibernate.service.common.AbstractHibernateService;

@Service
@Transactional
public class DepartmentService extends AbstractHibernateService<Department> implements SchoolService<Department> {

	@Autowired
	private SchoolDao<Department> dao;
	
	public DepartmentService() {
		super();
	}
	
	@Override
	protected Operations<Department> getDao() {
		return dao;
	}

}

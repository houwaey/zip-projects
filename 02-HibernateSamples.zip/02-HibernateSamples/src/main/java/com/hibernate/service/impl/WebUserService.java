package com.hibernate.service.impl;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hibernate.dao.UserDao;
import com.hibernate.dao.common.Operations;
import com.hibernate.entity.WebUser;
import com.hibernate.service.UserService;
import com.hibernate.service.common.AbstractHibernateService;

@Service
@Transactional
public class WebUserService extends AbstractHibernateService<WebUser> implements UserService<WebUser> {

	@Autowired
	private UserDao<WebUser> dao;
	
	public WebUserService() {
		super();
	}
	
	@Override
	protected Operations<WebUser> getDao() {
		return dao;
	}

}

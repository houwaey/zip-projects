package com.hibernate.service.impl;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hibernate.dao.UserDao;
import com.hibernate.dao.common.Operations;
import com.hibernate.entity.Student;
import com.hibernate.service.UserService;
import com.hibernate.service.common.AbstractHibernateService;

@Service
@Transactional
public class StudentUserService extends AbstractHibernateService<Student> implements UserService<Student> {

	@Autowired
	private UserDao<Student> dao;
	
	public StudentUserService() {
		super();
	}
	
	@Override
	protected Operations<Student> getDao() {
		return dao;
	}

}

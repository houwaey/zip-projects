package com.hibernate.dao.impl;

import org.springframework.stereotype.Repository;

import com.hibernate.dao.PersonDao;
import com.hibernate.dao.common.AbstractHibernateDao;
import com.hibernate.entity.Teacher;

@Repository
public class TeacherDao extends AbstractHibernateDao<Teacher> implements PersonDao<Teacher> {

	public TeacherDao() {
		super();
		setClazz(Teacher.class);
	}
	
}
package com.hibernate.dao.impl;

import org.springframework.stereotype.Repository;

import com.hibernate.dao.SchoolDao;
import com.hibernate.dao.common.AbstractHibernateDao;
import com.hibernate.entity.Department;

@Repository
public class DepartmentDao extends AbstractHibernateDao<Department> implements SchoolDao<Department> {

	public DepartmentDao() {
		super();
		setClazz(Department.class);
	}
	
}

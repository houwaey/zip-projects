package com.hibernate.dao;

import java.io.Serializable;

import com.hibernate.dao.common.Operations;

public interface UserDao<T extends Serializable> extends Operations<T> {

}
package com.hibernate.dao.impl;

import org.springframework.stereotype.Repository;

import com.hibernate.dao.UserDao;
import com.hibernate.dao.common.AbstractHibernateDao;
import com.hibernate.entity.Student;

@Repository
public class StudentUserDao extends AbstractHibernateDao<Student> implements UserDao<Student> {

	public StudentUserDao() {
		super();
		setClazz(Student.class);
	}
	
}
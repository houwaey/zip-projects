package com.hibernate.dao.impl;

import org.springframework.stereotype.Repository;

import com.hibernate.dao.UserDao;
import com.hibernate.dao.common.AbstractHibernateDao;
import com.hibernate.entity.WebUser;

@Repository
public class WebUserDao extends AbstractHibernateDao<WebUser> implements UserDao<WebUser> {

	public WebUserDao() {
		super();
		setClazz(WebUser.class);
	}
	
}
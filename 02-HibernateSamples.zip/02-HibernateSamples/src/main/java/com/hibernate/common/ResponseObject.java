package com.hibernate.common;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;

public class ResponseObject<T> {

	private int code;
	private String message;
	private T data;
	private List<FieldErrorDto> fieldErrors = new ArrayList<FieldErrorDto>();
	
	public ResponseObject(HttpStatus httpStatus) {
		this.code = httpStatus.value();
		this.message = httpStatus.getReasonPhrase();
	}
	
	public ResponseObject(HttpStatus httpStatus, List<FieldErrorDto> fieldErrors) {
		this.code = httpStatus.value();
		this.message = httpStatus.getReasonPhrase();
		this.fieldErrors = fieldErrors;
	}
	
	public ResponseObject(HttpStatus httpStatus, String customMessage) {
		this.code = httpStatus.value();
		this.message = customMessage;
	}
	
	public ResponseObject(T data, HttpStatus httpStatus) {
		this.code = httpStatus.value();
		this.message = httpStatus.getReasonPhrase();
		this.data = data;
	}
	
	public ResponseObject(T data, HttpStatus httpStatus, String customMessage) {
		this.code = httpStatus.value();
		this.message = customMessage;
		this.data = data;
	}
	
	public int getCode() {
		return code;
	}
	public String getMessage() {
		return message;
	}
	public T getData() {
		return data;
	}
	public List<FieldErrorDto> getFieldErrors() {
		return fieldErrors;
	}
}

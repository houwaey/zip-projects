package com.hibernate.entity;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.*;

@Entity
@Table(name = "student")
public class Student implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "student_id")
	private long studentId;
	
	@Column(name = "student_name", nullable = false, length = 100)
	private String studentName;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "saddress_id")
	private Address studentAddress;
	
	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "student_teacher", 
				joinColumns = { @JoinColumn(name = "student_id") },
				inverseJoinColumns = { @JoinColumn(name = "teacher_id") })
	private Set<Teacher> studentTeachers;

	public long getStudentId() {
		return studentId;
	}

	public void setStudentId(long studentId) {
		this.studentId = studentId;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public Address getStudentAddress() {
		return studentAddress;
	}

	public void setStudentAddress(Address studentAddress) {
		this.studentAddress = studentAddress;
	}

	public Set<Teacher> getStudentTeachers() {
		return studentTeachers;
	}

	public void setStudentTeachers(Set<Teacher> studentTeachers) {
		this.studentTeachers = studentTeachers;
	}
	
}

package com.hibernate.entity;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "department")
public class Department implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "department_id")
	private long departmentId;
	
	@Column(name = "department_name", nullable = false, length = 100)
	private String departmentName;
	
	@OneToMany(mappedBy = "teacherDepartment")
	@JsonIgnore
	private Set<Teacher> departmentTeachers;

	public long getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(long departmentId) {
		this.departmentId = departmentId;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	public Set<Teacher> getDepartmentTeachers() {
		return departmentTeachers;
	}

	public void setDepartmentTeachers(Set<Teacher> departmentTeachers) {
		this.departmentTeachers = departmentTeachers;
	}

}

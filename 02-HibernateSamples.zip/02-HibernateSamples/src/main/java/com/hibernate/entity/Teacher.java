package com.hibernate.entity;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "teacher")
public class Teacher implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "teacher_id")
	private long teacherId;
	
	@Column(name = "teacher_name", nullable = false, length = 100)
	private String teacherName;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "tadress_id")
	private Address teacherAddress;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "tdepartment_id", insertable = false, updatable = false)
	private Department teacherDepartment;
	
	@Column(name = "tdepartment_id")
	private long teacherDepartmentId;
	
	@ManyToMany(mappedBy = "studentTeachers")
	@JsonIgnore 								//is it the best solution?
	private Set<Student> teacherStudents;

	public long getTeacherId() {
		return teacherId;
	}

	public void setTeacherId(long teacherId) {
		this.teacherId = teacherId;
	}

	public String getTeacherName() {
		return teacherName;
	}

	public void setTeacherName(String teacherName) {
		this.teacherName = teacherName;
	}

	public Address getTeacherAddress() {
		return teacherAddress;
	}

	public void setTeacherAddress(Address teacherAddress) {
		this.teacherAddress = teacherAddress;
	}

	public Department getTeacherDepartment() {
		return teacherDepartment;
	}

	public void setTeacherDepartment(Department teacherDepartment) {
		this.teacherDepartment = teacherDepartment;
	}

	public long getTeacherDepartmentId() {
		return teacherDepartmentId;
	}

	public void setTeacherDepartmentId(long teacherDepartmentId) {
		this.teacherDepartmentId = teacherDepartmentId;
	}

	public Set<Student> getTeacherStudents() {
		return teacherStudents;
	}

	public void setTeacherStudents(Set<Student> teacherStudents) {
		this.teacherStudents = teacherStudents;
	}

}

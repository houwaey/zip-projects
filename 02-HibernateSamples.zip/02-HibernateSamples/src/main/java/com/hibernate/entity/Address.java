package com.hibernate.entity;

import java.io.Serializable;

import javax.persistence.*;

@Entity
@Table(name = "address")
public class Address implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "address_id")
	private long addressId;
	
	@Column(name = "address_street", nullable = false, length = 250)
	private String street;
	
	@Column(name = "address_city", nullable = false, length = 50)
	private String city;
	
	@Column(name = "address_state", nullable = false, length = 50)
	private String state;
	
	@Column(name = "address_zipcode", nullable = false, length = 10)
	private String zipcode;

	public long getAddressId() {
		return addressId;
	}

	public void setAddressId(long addressId) {
		this.addressId = addressId;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
	
}

package com.hibernate.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hibernate.common.FieldErrorDto;
import com.hibernate.common.ResponseObject;
import com.hibernate.entity.Student;
import com.hibernate.entity.WebUser;
import com.hibernate.pojo.WebUserRequest;
import com.hibernate.service.UserService;
import com.hibernate.validation.FieldValidator;

@RestController
@RequestMapping("/account")
public class AccountController {

	@Autowired
	private UserService<WebUser> webUserService;
	
	@Autowired
	private UserService<Student> studentUserService;
	
	@GetMapping("/students")
	public ResponseObject<List<Student>> findAllStudents() {
		List<Student> students = studentUserService.findAll();
		if (students.size() <= 0) {
			return new ResponseObject<List<Student>>(HttpStatus.NO_CONTENT);
		}
		return new ResponseObject<List<Student>>(students, HttpStatus.OK);
	}
	
	@PostMapping("/student")
	public ResponseObject<Void> createStudent(@RequestBody Student student) {
		boolean created = studentUserService.create(student);
		if (!created) {
			return new ResponseObject<Void>(HttpStatus.PRECONDITION_FAILED);
		}
		return new ResponseObject<Void>(HttpStatus.CREATED);
	}
	
	@GetMapping("/web-users")
	public ResponseObject<List<WebUser>> findAllWebUsers() {
		List<WebUser> users = webUserService.findAll();
		if (users.size() <= 0) {
			return new ResponseObject<List<WebUser>>(HttpStatus.NO_CONTENT);
		}
		return new ResponseObject<List<WebUser>>(users, HttpStatus.OK);
	}
	
	@GetMapping("/web-user/{id}")
	public ResponseObject<WebUser> findWebUserById(@PathVariable("id") long id) {
		WebUser user = webUserService.findOneById(id);
		if (user == null) {
			return new ResponseObject<WebUser>(HttpStatus.NOT_FOUND);
		}
		return new ResponseObject<WebUser>(user, HttpStatus.OK);
	}
	
	@PostMapping("/web-user")
	public ResponseObject<Void> createUser(@Valid @RequestBody WebUserRequest user, BindingResult result) {
		
		if (result.hasErrors()) {
			FieldValidator validator = new FieldValidator(result.getFieldErrors());
			return new ResponseObject<Void>(HttpStatus.PRECONDITION_FAILED, validator.getFieldErrors());
		}
		
		WebUser web = new WebUser();
		web.setUsername(user.getEmail());
		web.setEmail(user.getEmail());
		web.setPassword(user.getPassword());
		web.setStatus(user.getStatus());
		boolean created = webUserService.create(web);
		if (created) {
			return new ResponseObject<Void>(HttpStatus.CREATED);
		}
		return new ResponseObject<Void>(HttpStatus.PRECONDITION_FAILED);
	}
	
	/*@PostMapping("/web-user")
	public ResponseObject<Void> createUser(@Valid @RequestBody WebUser user, BindingResult result) {
		System.out.println("error count: " + result.);
		boolean created = webUserService.create(user);
		if (!created) {
			return new ResponseObject<Void>(HttpStatus.PRECONDITION_FAILED);
		}
		return new ResponseObject<Void>(HttpStatus.CREATED);
	}*/

}
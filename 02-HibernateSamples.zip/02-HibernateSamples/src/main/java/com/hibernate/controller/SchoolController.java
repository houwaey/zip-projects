package com.hibernate.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hibernate.common.ResponseObject;
import com.hibernate.entity.Department;
import com.hibernate.entity.Teacher;
import com.hibernate.service.PersonService;
import com.hibernate.service.SchoolService;

@RestController
@RequestMapping("/school")
public class SchoolController {

	@Autowired
	private SchoolService<Department> departmentService;
	
	@Autowired
	private PersonService<Teacher> teacherService;
	
	/* ------------------------------- DEPARTMENT - BEGIN ------------------------------- */
	
	@PostMapping("/department")
	public ResponseObject<Department> createDepartment(@RequestBody Department department) {
		boolean created = departmentService.create(department);
		if (!created) {
			return new ResponseObject<Department>(department, HttpStatus.PRECONDITION_FAILED);
		}
		return new ResponseObject<Department>(department, HttpStatus.CREATED);
	}
	
	@GetMapping("/department/{id}")
	public ResponseObject<Department> findDepartmentById(@PathVariable("id") long id) {
		Department department = departmentService.findOneById(id);
		if (department == null) {
			return new ResponseObject<Department>(HttpStatus.NOT_FOUND);
		}
		return new ResponseObject<Department>(department, HttpStatus.FOUND);
	}
	
	@GetMapping("/departments")
	public ResponseObject<List<Department>> findAllDepartments() {
		List<Department> departments = departmentService.findAll();
		if (departments.size() <= 0) {
			return new ResponseObject<List<Department>>(HttpStatus.NO_CONTENT);
		}
		return new ResponseObject<List<Department>>(departments, HttpStatus.FOUND);
	}
	
	/* ------------------------------- DEPARTMENT - END ------------------------------- */
	
	
	/* ------------------------------- TEACHER - BEGIN ------------------------------- */
	
	@PostMapping("/teacher")
	public ResponseObject<Teacher> createTeacher(@RequestBody Teacher teacher) {
		boolean created = teacherService.create(teacher);
		if (!created) {
			return new ResponseObject<Teacher>(teacher, HttpStatus.PRECONDITION_FAILED);
		}
		return new ResponseObject<Teacher>(teacher, HttpStatus.CREATED);
	}
	
	@GetMapping("/teacher/{id}")
	public ResponseObject<Teacher> findTeacherById(@PathVariable("id") long id) {
		Teacher teacher = teacherService.findOneById(id);
		if (teacher == null) {
			return new ResponseObject<Teacher>(HttpStatus.NOT_FOUND);
		}
		return new ResponseObject<Teacher>(teacher, HttpStatus.FOUND);
	}
	
	@GetMapping("/teachers")
	public ResponseObject<List<Teacher>> findAllTeachers() {
		List<Teacher> teachers = teacherService.findAll();
		if (teachers.size() <= 0) {
			return new ResponseObject<List<Teacher>>(HttpStatus.NO_CONTENT);
		}
		return new ResponseObject<List<Teacher>>(teachers, HttpStatus.FOUND);
	}
	
	/* ------------------------------- TEACHER - END ------------------------------- */
	
}

package com.library.tester;

import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.inject.Named;

import org.omnifaces.cdi.ViewScoped;

@Named
@ViewScoped
public class LibraryView implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private LibraryService libraryService;
	
	@Inject
	private LibrarySession librarySession;
	
	private String message;
	
	@PostConstruct
	public void init() {
		message = libraryService.getMessage();
		System.out.println("user: " + librarySession.getUsername());
		System.out.println("pass: " + librarySession.getPassword());
	}
	
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
}

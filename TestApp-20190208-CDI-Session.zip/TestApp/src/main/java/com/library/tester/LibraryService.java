package com.library.tester;

import java.io.Serializable;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Named;

@Named
@ApplicationScoped
public class LibraryService implements Serializable {

	private static final long serialVersionUID = 1L;

	public String getMessage() {
		return "Sample Message";
	}
	
}
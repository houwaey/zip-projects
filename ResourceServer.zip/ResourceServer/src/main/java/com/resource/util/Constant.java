package com.resource.util;

public class Constant {

	public static final String AUTH_SERVER = "http://localhost:8081/auth-server/oauth/token";
	public static final String GRANT_CLIENTCREDENTIALS = "/grant-type/client-credentials/{token}";
	
}

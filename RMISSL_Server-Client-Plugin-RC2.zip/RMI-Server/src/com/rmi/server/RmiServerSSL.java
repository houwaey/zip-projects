package com.rmi.server;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;

import com.rmi.plugin.dto.SSLFile;
import com.rmi.plugin.ssl.SslClientSocketFactory;
import com.rmi.plugin.ssl.SslServerSocketFactory;
import com.rmi.plugin.util.Util;
import com.rmi.server.impl.AccountManagement;
import com.rmi.server.impl.UserInfo;

public class RmiServerSSL {
	
	private static final File SERVER_JKS_FILE = new File(Util.getWorkingDirectory() + "/cert/server_20190306.jks");
	private static final File SERVER_TS_FILE = new File(Util.getWorkingDirectory() + "/cert/server_20190306.ts");
	private static final File CLIENT_JKS_FILE = new File(Util.getWorkingDirectory() + "/cert/client_20190306.jks");
	private static final File CLIENT_TS_FILE = new File(Util.getWorkingDirectory() + "/cert/client_20190306.ts");

	public static void main(String[] args) throws UnrecoverableKeyException, KeyManagementException,
			FileNotFoundException, NoSuchAlgorithmException, CertificateException, KeyStoreException, IOException {
		System.setProperty("java.security.policy", Util.getWorkingDirectory() + "/cert/all.policy");
        System.setSecurityManager(new SecurityManager());
		System.out.println("RMI Server started...");
		
		SslServerSocketFactory ssf = new SslServerSocketFactory(
				new SSLFile(SERVER_JKS_FILE, "pa55w0rd"), 
				new SSLFile(SERVER_TS_FILE, "pa55w0rd")
			);
		SslClientSocketFactory csf = new SslClientSocketFactory(
				new SSLFile(CLIENT_JKS_FILE, "pa55w0rd"), 
				new SSLFile(CLIENT_TS_FILE, "pa55w0rd")
			);
		Registry registry = LocateRegistry.createRegistry(4000, csf, ssf);
		System.out.println("RMI Registry created.");
		
		registry.rebind("UserInfo", UnicastRemoteObject.exportObject(new UserInfo(), 0));
		registry.rebind("AccountManagement", UnicastRemoteObject.exportObject(new AccountManagement(), 0));
		System.out.println("PeerServer bound in registry.");
	}

}
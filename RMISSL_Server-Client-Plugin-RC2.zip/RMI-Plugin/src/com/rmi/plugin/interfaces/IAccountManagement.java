package com.rmi.plugin.interfaces;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface IAccountManagement extends Remote {

	boolean lock(int id) throws RemoteException;
	
	boolean unlock(int id) throws RemoteException;
	
	boolean activate(int id) throws RemoteException;
	
	boolean deactivate(int id) throws RemoteException;
	
}

package com.rmi.plugin.interfaces;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.Map;

import com.rmi.plugin.dto.PersonalInfo;

public interface IUserInfo extends Remote {

	void addInfo(PersonalInfo info) throws RemoteException;
	
	PersonalInfo getInfo(int id) throws RemoteException;
	
	Map<Integer, PersonalInfo> getAllInfo() throws RemoteException;
	
}
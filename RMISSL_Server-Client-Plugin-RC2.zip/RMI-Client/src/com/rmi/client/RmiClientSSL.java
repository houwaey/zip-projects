package com.rmi.client;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.rmi.NotBoundException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;

import com.rmi.plugin.dto.SSLFile;
import com.rmi.plugin.interfaces.IAccountManagement;
import com.rmi.plugin.ssl.SslClientSocketFactory;
import com.rmi.plugin.util.Util;

public class RmiClientSSL {
	
	private static final File CLIENT_JKS_FILE = new File(Util.getWorkingDirectory() + "/cert/client_20190306.jks");
	private static final File CLIENT_TS_FILE = new File(Util.getWorkingDirectory() + "/cert/client_20190306.ts");

	public static void main(String[] args)
			throws UnrecoverableKeyException, KeyManagementException, FileNotFoundException, NoSuchAlgorithmException,
			CertificateException, KeyStoreException, IOException, NotBoundException {
		SslClientSocketFactory csf = new SslClientSocketFactory(
				new SSLFile(CLIENT_JKS_FILE, "pa55w0rd"), 
				new SSLFile(CLIENT_TS_FILE, "pa55w0rd")
			);
		Registry registry = LocateRegistry.getRegistry("127.0.0.1", 4000, csf);

		IAccountManagement acctMgmt = (IAccountManagement) registry.lookup("AccountManagement");
		System.out.println("activate: " + acctMgmt.activate(1));
		System.out.println("deactivate: " + acctMgmt.deactivate(2));
		System.out.println("lock: " + acctMgmt.lock(3));
		System.out.println("unlock: " + acctMgmt.unlock(4));
	}

}
package com.java8.interfaces;

public interface MathOperation {

	int operation(int a, int b);
	
}

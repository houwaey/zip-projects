package com.java8.app;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.BeforeClass;
import org.junit.Test;

import com.java8.interfaces.MathOperation;

public class TestCollection {

	private static List<String> names = new ArrayList<String>();
	
	@BeforeClass
	public static void setUp() {
		names.add("B ");
	    names.add("D ");
	    names.add("A ");
	    names.add("C ");
	    names.add("E ");
	}
	
	@Test
	public void test_sort() {
		Collections.sort(names, (s1, s2) -> s1.compareTo(s2));
		System.out.println(names);
	}
	
	@Test
	public void test_lambda() {
		//with type decalaration
		MathOperation add = (int a, int b) -> a + b;
		
		//without type declaration
		MathOperation sub = (a, b) -> a - b;
		
		//with return statement along with curly braces
		MathOperation mul = (int a, int b) -> { return a * b; };
		
		MathOperation div = (int a, int b) -> a / b;
		
		System.out.println("10 + 5 = " + operate(10, 5, add));
	    System.out.println("10 - 5 = " + operate(10, 5, sub));
	    System.out.println("10 x 5 = " + operate(10, 5, mul));
	    System.out.println("10 / 5 = " + operate(10, 5, div));
	}
	
	private int operate(int a, int b, MathOperation mathOperation) {
		return mathOperation.operation(a, b);
	}
	
}

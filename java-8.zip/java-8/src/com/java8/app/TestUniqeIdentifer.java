package com.java8.app;

import org.junit.Test;

import com.java8.common.GetNetworkAddress;

public class TestUniqeIdentifer {

	@Test
	public void getMac() {
		System.out.println("IP: " + GetNetworkAddress.GetAddress("ip"));
	}
	
}

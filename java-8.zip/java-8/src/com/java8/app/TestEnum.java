package com.java8.app;

import com.java8.enums.AccountStatus;

public class TestEnum {

	public static void main(String[] args) {
		System.out.println("id: " + AccountStatus.ACTIVE.getId());
		System.out.println("initial: " + AccountStatus.ACTIVE.getInitial());
		System.out.println("value: " + AccountStatus.ACTIVE.getValue());
		System.out.println("this: " + AccountStatus.ACTIVE.name());
	}
	
}
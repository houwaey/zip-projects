package com.java8.app;

import org.apache.commons.lang3.Validate;
import org.apache.commons.text.WordUtils;

public class TestApacheCommons {

	public static void main(String[] args) {
		
		String message = null;
		
		try {
			Validate.notNull(message, "null keme");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		System.out.println(WordUtils.capitalizeFully("the BIG broWn fOx juMPs oveR the LAZY dog"));
		
	}
	
}

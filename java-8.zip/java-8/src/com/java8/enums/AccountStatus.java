package com.java8.enums;

public enum AccountStatus {

	ACTIVE(0, "A", "Active"),
	INACTIVE(1, "I", "Inactive"),
	LOCKED(2, "L", "Locked");
	
	private int id;
	private String initial;
	private String value;
	
	AccountStatus(int id, String initial, String value) {
		this.id = id;
		this.initial = initial;
		this.value = value;
	}

	public int getId() {
		return id;
	}

	public String getInitial() {
		return initial;
	}

	public String getValue() {
		return value;
	}

}
